extends RefCounted
## Everything that is saved between play sessions: cash, upgrades, paint colour.

const SAVE_PATH := "user://rickshaw_save.cfg"
const MAX_LEVEL := 5
const PAINT_COST := 40

const UP_NAMES: Array[String] = ["Better tires", "Smooth chain", "Strong legs", "Comfy seat"]
const UP_DESCS: Array[String] = [
	"More grip and a little more top speed",
	"Faster acceleration",
	"Stamina lasts longer",
	"Passengers tip more",
]
const UP_COSTS: Array = [
	[120, 300, 650, 1300, 2400],
	[100, 260, 560, 1100, 2100],
	[140, 320, 620, 1200, 2300],
	[150, 350, 700, 1400, 2600],
]

const PAINT_COLORS: Array[Color] = [
	Color(0.78, 0.10, 0.12), Color(0.15, 0.35, 0.80), Color(0.10, 0.55, 0.30),
	Color(0.55, 0.25, 0.70), Color(0.95, 0.45, 0.10), Color(0.90, 0.30, 0.55),
]

var money := 0
var trips := 0
var paint := 0
var levels: Array[int] = [0, 0, 0, 0]

# Story and stats
var foods := 0
var mission_index := 0
var mission_progress := 0
var unlocked: Array[String] = []
var zones_seen := 0
var rain_trips := 0
var night_trips := 0
var last_daily := 0
var streak := 0

# Settings
var music_on := true
var volume := 0.8
var quality := 1
var show_stats := false
var tutorial_done := false


func upgrade_cost(i: int) -> int:
	var lv: int = levels[i]
	if lv >= MAX_LEVEL:
		return -1
	var costs: Array = UP_COSTS[i]
	return int(costs[lv])


func try_buy(i: int) -> bool:
	var cost: int = upgrade_cost(i)
	if cost < 0 or money < cost:
		return false
	money -= cost
	levels[i] += 1
	save_game()
	return true


func try_repaint() -> bool:
	if money < PAINT_COST:
		return false
	money -= PAINT_COST
	paint = (paint + 1) % PAINT_COLORS.size()
	save_game()
	return true


## Erase cash, upgrades and paint. Settings and the tutorial flag are kept.
func reset_progress() -> void:
	money = 0
	trips = 0
	paint = 0
	for i in levels.size():
		levels[i] = 0
	foods = 0
	mission_index = 0
	mission_progress = 0
	unlocked.clear()
	zones_seen = 0
	rain_trips = 0
	night_trips = 0
	save_game()


func _today() -> int:
	return int(Time.get_unix_time_from_system() / 86400.0)


func daily_available() -> bool:
	return _today() > last_daily


## What claiming the daily reward would pay right now.
func daily_amount() -> int:
	var next_streak := 1
	if _today() - last_daily == 1:
		next_streak = streak + 1
	return 50 + 25 * mini(next_streak - 1, 6)


func claim_daily() -> int:
	if not daily_available():
		return 0
	var amount := daily_amount()
	if _today() - last_daily == 1:
		streak += 1
	else:
		streak = 1
	last_daily = _today()
	money += amount
	save_game()
	return amount


func paint_color() -> Color:
	return PAINT_COLORS[paint]


func save_game() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("game", "money", money)
	cfg.set_value("game", "trips", trips)
	cfg.set_value("game", "paint", paint)
	cfg.set_value("game", "levels", levels)
	cfg.set_value("story", "foods", foods)
	cfg.set_value("story", "mission_index", mission_index)
	cfg.set_value("story", "mission_progress", mission_progress)
	cfg.set_value("story", "unlocked", unlocked)
	cfg.set_value("story", "zones_seen", zones_seen)
	cfg.set_value("story", "rain_trips", rain_trips)
	cfg.set_value("story", "night_trips", night_trips)
	cfg.set_value("story", "last_daily", last_daily)
	cfg.set_value("story", "streak", streak)
	cfg.set_value("settings", "music_on", music_on)
	cfg.set_value("settings", "volume", volume)
	cfg.set_value("settings", "quality", quality)
	cfg.set_value("settings", "show_stats", show_stats)
	cfg.set_value("settings", "tutorial_done", tutorial_done)
	cfg.save(SAVE_PATH)


func load_game() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	money = maxi(int(cfg.get_value("game", "money", 0)), 0)
	trips = maxi(int(cfg.get_value("game", "trips", 0)), 0)
	paint = clampi(int(cfg.get_value("game", "paint", 0)), 0, PAINT_COLORS.size() - 1)
	foods = maxi(int(cfg.get_value("story", "foods", 0)), 0)
	mission_index = maxi(int(cfg.get_value("story", "mission_index", 0)), 0)
	mission_progress = maxi(int(cfg.get_value("story", "mission_progress", 0)), 0)
	var ids: Array = cfg.get_value("story", "unlocked", [])
	unlocked.clear()
	for id in ids:
		unlocked.append(str(id))
	zones_seen = int(cfg.get_value("story", "zones_seen", 0))
	rain_trips = int(cfg.get_value("story", "rain_trips", 0))
	night_trips = int(cfg.get_value("story", "night_trips", 0))
	last_daily = int(cfg.get_value("story", "last_daily", 0))
	streak = int(cfg.get_value("story", "streak", 0))
	music_on = bool(cfg.get_value("settings", "music_on", true))
	volume = clampf(float(cfg.get_value("settings", "volume", 0.8)), 0.0, 1.0)
	quality = clampi(int(cfg.get_value("settings", "quality", 1)), 0, 2)
	show_stats = bool(cfg.get_value("settings", "show_stats", false))
	tutorial_done = bool(cfg.get_value("settings", "tutorial_done", false))
	var saved: Array = cfg.get_value("game", "levels", [0, 0, 0, 0])
	for i in levels.size():
		if i < saved.size():
			levels[i] = clampi(int(saved[i]), 0, MAX_LEVEL)
