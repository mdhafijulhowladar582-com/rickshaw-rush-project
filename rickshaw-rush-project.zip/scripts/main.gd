extends Node3D
## Rickshaw Rush, phase 0 + 1: performance test city and the drivable rickshaw.
## Desktop test keys: A/D or arrows = steer, W/Up/Space = pedal, S/Down = brake, B = bell, R = reset.

const RickshawScript = preload("res://scripts/player/rickshaw.gd")
const ChaseCameraScript = preload("res://scripts/player/chase_camera.gd")
const CityScript = preload("res://scripts/world/city.gd")
const TouchControlsScript = preload("res://scripts/ui/touch_controls.gd")
const HudScript = preload("res://scripts/ui/hud.gd")
const UiTheme = preload("res://scripts/ui/ui_theme.gd")
const GameStateScript = preload("res://scripts/game/game_state.gd")
const TripScript = preload("res://scripts/game/trip_manager.gd")
const TripHudScript = preload("res://scripts/ui/trip_hud.gd")
const GarageScript = preload("res://scripts/ui/garage_panel.gd")

const SPAWN := Vector3(0.0, 0.04, 0.0)
const QUALITY_NAMES: Array[String] = ["Low", "Medium", "High"]
const SUBDIVS: Array[int] = [2, 3, 4]       # plots per block side: 4, 9, 16 buildings per block
const STRESS_NAMES: Array[String] = ["Normal", "Dense", "Very dense"]
const FOG_COLOR := Color(0.80, 0.74, 0.62)

var quality := 1
var stress := 0

var env: Environment
var city
var rickshaw
var cam
var touch
var hud
var quality_btn: Button
var stress_btn: Button
var state
var trips
var trip_hud
var garage


func _ready() -> void:
	DisplayServer.screen_set_keep_on(true)
	_setup_environment()

	state = GameStateScript.new()
	state.load_game()

	city = CityScript.new()
	add_child(city)
	city.build(SUBDIVS[stress])

	rickshaw = RickshawScript.new()
	add_child(rickshaw)
	rickshaw.reset_to(SPAWN, 0.0)
	_apply_upgrades()

	cam = ChaseCameraScript.new()
	add_child(cam)
	cam.target = rickshaw
	cam.current = true

	trips = TripScript.new()
	add_child(trips)
	trips.setup(rickshaw, city, state)

	_build_ui()
	_apply_quality()
	_refresh_info()
	trips.start()


func _setup_environment() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = FOG_COLOR
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.85, 0.82, 0.78)
	env.ambient_light_energy = 0.65
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = FOG_COLOR
	env.fog_density = 0.015

	var world_env := WorldEnvironment.new()
	world_env.environment = env
	add_child(world_env)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52.0, -35.0, 0.0)
	sun.light_color = Color(1.0, 0.92, 0.78)
	sun.light_energy = 1.1
	sun.shadow_enabled = false
	add_child(sun)


func _build_ui() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 10
	add_child(layer)

	var root := Control.new()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = UiTheme.make()
	layer.add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	hud = HudScript.new()
	root.add_child(hud)
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.rickshaw = rickshaw

	touch = TouchControlsScript.new()
	root.add_child(touch)
	touch.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	touch.bell_pressed.connect(rickshaw.ring_bell)

	trip_hud = TripHudScript.new()
	root.add_child(trip_hud)
	trip_hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	trip_hud.rickshaw = rickshaw
	trip_hud.trips = trips
	trip_hud.state = state
	trips.message.connect(trip_hud.show_toast)

	var box := VBoxContainer.new()
	box.anchor_left = 1.0
	box.anchor_right = 1.0
	box.anchor_top = 0.0
	box.anchor_bottom = 0.0
	box.offset_left = -220.0
	box.offset_right = -20.0
	box.offset_top = 20.0
	box.add_theme_constant_override("separation", 10)
	root.add_child(box)

	quality_btn = _make_button("", _on_quality_pressed)
	stress_btn = _make_button("", _on_stress_pressed)
	box.add_child(quality_btn)
	box.add_child(stress_btn)
	box.add_child(_make_button("Reset position", _on_reset_pressed))
	box.add_child(_make_button("Garage", _on_garage_pressed))

	garage = GarageScript.new()
	root.add_child(garage)
	garage.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	garage.setup(state)
	garage.changed.connect(_apply_upgrades)
	garage.closed.connect(_on_garage_closed)


func _make_button(label: String, callback: Callable) -> Button:
	var b := Button.new()
	b.text = label
	b.custom_minimum_size = Vector2(200.0, 52.0)
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(callback)
	return b


func _physics_process(_delta: float) -> void:
	# Touch first, keyboard overrides for desktop testing.
	var steer: float = touch.steer
	var pedal: bool = touch.pedal_down
	var brake: float = touch.brake

	var k := 0.0
	if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT):
		k -= 1.0
	if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT):
		k += 1.0
	if absf(k) > 0.0:
		steer = k
	if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP) or Input.is_physical_key_pressed(KEY_SPACE):
		pedal = true
	if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN):
		brake = 1.0

	rickshaw.steer = steer
	rickshaw.pedaling = pedal
	rickshaw.braking = brake


func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.physical_keycode == KEY_B:
			rickshaw.ring_bell()
		elif event.physical_keycode == KEY_R:
			_on_reset_pressed()


func _on_reset_pressed() -> void:
	rickshaw.reset_to(SPAWN, 0.0)
	cam.snap()


func _on_quality_pressed() -> void:
	quality = (quality + 1) % QUALITY_NAMES.size()
	_apply_quality()


func _on_stress_pressed() -> void:
	stress = (stress + 1) % SUBDIVS.size()
	city.build(SUBDIVS[stress])
	_refresh_info()


func _apply_quality() -> void:
	var scales: Array[float] = [0.65, 0.85, 1.0]
	var fars: Array[float] = [130.0, 190.0, 260.0]
	var fogs: Array[float] = [0.022, 0.015, 0.011]
	var vp := get_viewport()
	vp.scaling_3d_scale = scales[quality]
	vp.msaa_3d = Viewport.MSAA_2X if quality == 2 else Viewport.MSAA_DISABLED
	cam.far = fars[quality]
	env.fog_density = fogs[quality]
	quality_btn.text = "Graphics: " + QUALITY_NAMES[quality]
	stress_btn.text = "City: " + STRESS_NAMES[stress]


func _refresh_info() -> void:
	stress_btn.text = "City: " + STRESS_NAMES[stress]
	hud.info_text = "Buildings  %d" % city.building_count


func _apply_upgrades() -> void:
	var tires: int = state.levels[0]
	var chain: int = state.levels[1]
	var legs: int = state.levels[2]
	rickshaw.grip = 5.5 + 1.0 * float(tires)
	rickshaw.speed_mult = 1.0 + 0.04 * float(tires) + 0.03 * float(chain)
	rickshaw.accel_mult = 1.0 + 0.2 * float(chain)
	rickshaw.drain_mult = 1.0 - 0.2 * float(legs)
	rickshaw.set_hood_color(state.paint_color())


func _on_garage_pressed() -> void:
	touch.release_all()
	garage.open()
	get_tree().paused = true


func _on_garage_closed() -> void:
	get_tree().paused = false


func _notification(what: int) -> void:
	# 2015 = the app is sent to the background on Android
	if what == 2015 or what == NOTIFICATION_WM_CLOSE_REQUEST:
		if state != null:
			state.save_game()
