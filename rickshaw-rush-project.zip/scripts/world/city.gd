extends Node3D
## Procedural old-city grid: roads, raised footpath blocks, lane dashes and buildings.
## Everything is drawn with a handful of MultiMeshes so the draw-call count stays tiny.

const BLOCKS := 18              # blocks per side (keep even so a road crosses the origin)
const BLOCK := 36.0             # block size in metres
const ROAD := 9.0               # road width in metres
const PITCH := BLOCK + ROAD
const SLAB_H := 0.25            # footpath height

const PALETTE: Array[Color] = [
	Color(0.86, 0.72, 0.52), Color(0.78, 0.45, 0.36), Color(0.90, 0.82, 0.62),
	Color(0.55, 0.66, 0.60), Color(0.82, 0.60, 0.40), Color(0.70, 0.56, 0.50),
	Color(0.93, 0.88, 0.76), Color(0.60, 0.52, 0.64), Color(0.84, 0.76, 0.30),
	Color(0.45, 0.60, 0.72),
]

var building_count := 0
var _rng := RandomNumberGenerator.new()


func build(sub: int, seed_value: int = 1234) -> void:
	for c in get_children():
		c.queue_free()
	_rng.seed = seed_value
	_build_ground()
	_build_roads()
	_build_slabs()
	_build_dashes()
	_build_buildings(sub)
	_build_collision()


## World coordinate of the centre line of road number i (0 .. BLOCKS).
func road_center(i: int) -> float:
	return (float(i) - float(BLOCKS) * 0.5) * PITCH


func _build_ground() -> void:
	var mi := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(3000.0, 3000.0)
	mi.mesh = plane
	mi.material_override = _flat_mat(Color(0.42, 0.39, 0.33), false)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)


func _build_roads() -> void:
	var span := float(BLOCKS) * PITCH + ROAD
	var xforms: Array[Transform3D] = []
	for i in BLOCKS + 1:
		var c := road_center(i)
		xforms.append(_xform(Vector3(span, 0.04, ROAD), Vector3(0.0, 0.02, c)))
		xforms.append(_xform(Vector3(ROAD, 0.04, span), Vector3(c, 0.02, 0.0)))
	_add_multimesh(BoxMesh.new(), xforms, [], _flat_mat(Color(0.17, 0.17, 0.18), false))


func _build_slabs() -> void:
	var xforms: Array[Transform3D] = []
	for bx in BLOCKS:
		for bz in BLOCKS:
			var cx := road_center(bx) + PITCH * 0.5
			var cz := road_center(bz) + PITCH * 0.5
			xforms.append(_xform(Vector3(BLOCK, SLAB_H, BLOCK), Vector3(cx, SLAB_H * 0.5, cz)))
	_add_multimesh(BoxMesh.new(), xforms, [], _flat_mat(Color(0.58, 0.55, 0.50), false))


func _build_dashes() -> void:
	var xforms: Array[Transform3D] = []
	for i in BLOCKS + 1:
		var c := road_center(i)
		for s in BLOCKS:
			var start := road_center(s) + ROAD * 0.5 + 3.0
			var stop := road_center(s + 1) - ROAD * 0.5 - 3.0
			var p := start + 1.5
			while p + 1.5 <= stop:
				xforms.append(_xform(Vector3(3.0, 0.02, 0.22), Vector3(p, 0.045, c)))
				xforms.append(_xform(Vector3(0.22, 0.02, 3.0), Vector3(c, 0.045, p)))
				p += 7.0
	_add_multimesh(BoxMesh.new(), xforms, [], _flat_mat(Color(0.95, 0.92, 0.75), false))


func _build_buildings(sub: int) -> void:
	var xforms: Array[Transform3D] = []
	var colors: Array[Color] = []
	var plot := BLOCK / float(sub)
	for bx in BLOCKS:
		for bz in BLOCKS:
			var ox := road_center(bx) + ROAD * 0.5
			var oz := road_center(bz) + ROAD * 0.5
			for px in sub:
				for pz in sub:
					var w := plot * _rng.randf_range(0.72, 0.92)
					var d := plot * _rng.randf_range(0.72, 0.92)
					var h := _rng.randf_range(7.0, 22.0)
					if _rng.randf() < 0.12:
						h = _rng.randf_range(22.0, 42.0)
					var cx := ox + (float(px) + 0.5) * plot
					var cz := oz + (float(pz) + 0.5) * plot
					xforms.append(_xform(Vector3(w, h, d), Vector3(cx, SLAB_H + h * 0.5, cz)))
					var base: Color = PALETTE[_rng.randi() % PALETTE.size()]
					var j := _rng.randf_range(0.90, 1.05)
					colors.append(Color(base.r * j, base.g * j, base.b * j))
	building_count = xforms.size()
	_add_multimesh(BoxMesh.new(), xforms, colors, _flat_mat(Color.WHITE, true))


## One solid box per block (the rickshaw stays on the roads) plus walls round the city edge.
func _build_collision() -> void:
	var body := StaticBody3D.new()
	add_child(body)

	var block_shape := BoxShape3D.new()
	block_shape.size = Vector3(BLOCK, 30.0, BLOCK)
	for bx in BLOCKS:
		for bz in BLOCKS:
			var cs := CollisionShape3D.new()
			cs.shape = block_shape
			cs.position = Vector3(road_center(bx) + PITCH * 0.5, 15.0, road_center(bz) + PITCH * 0.5)
			body.add_child(cs)

	var half := float(BLOCKS) * PITCH * 0.5 + ROAD * 0.5 + 2.0
	var length := half * 2.0 + 20.0
	var wall_x := BoxShape3D.new()
	wall_x.size = Vector3(length, 10.0, 2.0)
	var wall_z := BoxShape3D.new()
	wall_z.size = Vector3(2.0, 10.0, length)
	var sides: Array[float] = [-1.0, 1.0]
	for side in sides:
		var a := CollisionShape3D.new()
		a.shape = wall_x
		a.position = Vector3(0.0, 5.0, side * half)
		body.add_child(a)
		var b := CollisionShape3D.new()
		b.shape = wall_z
		b.position = Vector3(side * half, 5.0, 0.0)
		body.add_child(b)


func _xform(scale_v: Vector3, pos: Vector3) -> Transform3D:
	return Transform3D(Basis.from_scale(scale_v), pos)


func _add_multimesh(mesh: Mesh, xforms: Array[Transform3D], colors: Array, mat: Material) -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = colors.size() > 0
	mm.mesh = mesh
	mm.instance_count = xforms.size()
	for i in xforms.size():
		mm.set_instance_transform(i, xforms[i])
		if colors.size() > 0:
			mm.set_instance_color(i, colors[i])
	var inst := MultiMeshInstance3D.new()
	inst.multimesh = mm
	inst.material_override = mat
	inst.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(inst)


func _flat_mat(c: Color, vertex_colors: bool) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 1.0
	m.metallic_specular = 0.0
	m.vertex_color_use_as_albedo = vertex_colors
	return m
