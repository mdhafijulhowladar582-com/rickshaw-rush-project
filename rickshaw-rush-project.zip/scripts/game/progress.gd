extends Node
## Story missions (30, in six chapters), achievements and the counters behind them.

signal message(text: String)
signal sfx(sound: String)

const CHAPTERS: Array[String] = ["Fresh in Dhaka", "Making a name", "Around the city", "Pro driver", "City legend", "King of the road"]

# kind: what counts. goal: how many. Chapters are 5 missions each.
const MISSIONS: Array = [
	{"title": "First day", "story": "Rahim just arrived in Dhaka.|Earn your first fares.", "kind": "trips", "goal": 3, "reward": 100},
	{"title": "Mind the clock", "story": "Fast drivers earn tips.|Get a tip on 2 trips.", "kind": "tips", "goal": 2, "reward": 120},
	{"title": "Rainy days", "story": "Rain keeps the buses away.|Finish 3 trips in the rain.", "kind": "rain", "goal": 3, "reward": 200},
	{"title": "Careful driver", "story": "Careful drivers get more rides.|Finish 3 trips without a crash.", "kind": "clean", "goal": 3, "reward": 200},
	{"title": "Old Dhaka run", "story": "Narrow lanes and big crowds.|Drop 3 passengers in Old Dhaka.", "kind": "zone0", "goal": 3, "reward": 250},

	{"title": "Student fares", "story": "Exams are near.|Take 3 students to their classes.", "kind": "type0", "goal": 3, "reward": 250},
	{"title": "Night shift", "story": "The city never sleeps.|Finish 3 trips at night.", "kind": "night", "goal": 3, "reward": 300},
	{"title": "Tourist guide", "story": "Visitors want to see Dhaka.|Carry 3 tourists.", "kind": "type3", "goal": 3, "reward": 300},
	{"title": "Office rush", "story": "Everyone is late for work.|Carry 3 office workers.", "kind": "type1", "goal": 3, "reward": 300},
	{"title": "Express", "story": "Some rides cannot wait.|Deliver 3 trips with half the time left.", "kind": "fast", "goal": 3, "reward": 400},

	{"title": "Motijheel business", "story": "Money talks in Motijheel.|Drop 3 passengers there.", "kind": "zone1", "goal": 3, "reward": 350},
	{"title": "Market day", "story": "Bags full of shopping.|Carry 3 shoppers.", "kind": "type2", "goal": 3, "reward": 350},
	{"title": "Snack break", "story": "A driver needs energy.|Grab 5 street snacks.", "kind": "food", "goal": 5, "reward": 200},
	{"title": "Dhanmondi evenings", "story": "Quiet streets, big houses.|Drop 3 passengers in Dhanmondi.", "kind": "zone2", "goal": 3, "reward": 350},
	{"title": "Respect the law", "story": "The police are watching.|Finish 5 trips in a row with no fines.", "kind": "lawful", "goal": 5, "reward": 450},

	{"title": "Sadarghat river", "story": "Boats, crowds and shouting.|Drop 3 passengers in Sadarghat.", "kind": "zone3", "goal": 3, "reward": 350},
	{"title": "Rush hour hero", "story": "Jams are your battlefield.|Finish 3 trips in rush hour.", "kind": "rush", "goal": 3, "reward": 450},
	{"title": "Elder care", "story": "Take it gently, but on time.|Carry 3 elderly uncles.", "kind": "type4", "goal": 3, "reward": 400},
	{"title": "Perfect streak", "story": "Never be late.|Finish 5 trips in a row on time.", "kind": "streak", "goal": 5, "reward": 500},
	{"title": "Big fare", "story": "A rich customer waves you down.|Earn Tk 160 or more on one trip.", "kind": "bigfare", "goal": 1, "reward": 400},

	{"title": "Tip master", "story": "Your service is the talk of town.|Get a tip on 5 trips.", "kind": "tips", "goal": 5, "reward": 500},
	{"title": "Stormy night", "story": "Dark, wet and dangerous.|Finish 3 trips at night in the rain.", "kind": "nightrain", "goal": 3, "reward": 600},
	{"title": "Fast and clean", "story": "Speed without crashes.|3 fast trips with no crash.", "kind": "fastclean", "goal": 3, "reward": 600},
	{"title": "Savings", "story": "Mother needs money back home.|Hold Tk 3000 at once.", "kind": "cash", "goal": 3000, "reward": 600},
	{"title": "Tourist season", "story": "The hotels are full.|Carry 6 tourists.", "kind": "type3", "goal": 6, "reward": 600},

	{"title": "Old friends", "story": "Everyone knows your bell now.|Finish 40 trips in total.", "kind": "total", "goal": 40, "reward": 700},
	{"title": "Snack lover", "story": "Your legs run on street food.|Grab 15 street snacks.", "kind": "food", "goal": 15, "reward": 400},
	{"title": "Smooth operator", "story": "A model citizen of the road.|Finish 10 trips in a row with no fines.", "kind": "lawful", "goal": 10, "reward": 800},
	{"title": "Hospital dash", "story": "Lives depend on you.|Carry 3 patients to the hospital.", "kind": "type5", "goal": 3, "reward": 800},
	{"title": "King of the road", "story": "All of Dhaka knows your name.|Finish 75 trips in total.", "kind": "total", "goal": 75, "reward": 1500},
]

const ACH_IDS: Array[String] = ["first_fare", "regular", "veteran", "big_tip", "rain_rider", "night_owl", "rich", "tuned", "explorer", "smooth", "foodie", "lawful", "maxed"]
const ACH_TITLES: Array[String] = ["First fare", "Regular", "Veteran", "Big tipper", "Rain rider", "Night owl", "Rich", "Tuned up", "Explorer", "Smooth ride", "Foodie", "Law abiding", "Maxed out"]
const ACH_DESCS: Array[String] = [
	"Finish a trip", "Finish 25 trips", "Finish 100 trips", "Get a tip of Tk 40 or more",
	"Finish 5 trips in the rain", "Finish 5 trips at night", "Hold Tk 5000 at once",
	"Buy one of every upgrade", "Visit all four areas", "5 trips in a row without a crash",
	"Grab 30 street snacks", "10 trips in a row without a fine", "Fully upgrade one part",
]
const ACH_REWARDS: Array[int] = [20, 100, 400, 100, 150, 150, 400, 150, 150, 200, 200, 250, 500]

var state = null
var trips = null
var rickshaw = null
var weather = null
var city = null

var _crashes := 0
var _fines_this_trip := 0
var _clean_streak := 0
var _lawful_streak := 0
var _last_tip := 0
var _timer := 0.0


func setup(s, t, r, w, c) -> void:
	state = s
	trips = t
	rickshaw = r
	weather = w
	city = c
	trips.trip_started.connect(_on_trip_started)
	trips.trip_finished.connect(_on_trip_finished)
	rickshaw.crashed.connect(_on_crashed)


## Tell the player what the current mission is (called once the HUD exists).
func announce() -> void:
	var idx := int(state.mission_index)
	if idx >= MISSIONS.size():
		return
	var m: Dictionary = MISSIONS[idx]
	var text := "Mission %d: %s|%s" % [idx + 1, m["title"], m["story"]]
	if idx % 5 == 0:
		text = "Chapter %d: %s|%s" % [idx / 5 + 1, CHAPTERS[mini(idx / 5, CHAPTERS.size() - 1)], text]
	message.emit(text)


func mission_text() -> String:
	if state == null:
		return ""
	var idx := int(state.mission_index)
	if idx >= MISSIONS.size():
		return "All missions complete!"
	var m: Dictionary = MISSIONS[idx]
	return "Mission %d/%d: %s   %d/%d" % [idx + 1, MISSIONS.size(), m["title"], _mission_value(m), int(m["goal"])]


## A window of the mission list around the current mission.
func mission_lines() -> String:
	var total := MISSIONS.size()
	var cur := int(state.mission_index)
	var start := clampi(cur - 3, 0, maxi(total - 9, 0))
	var stop := mini(start + 9, total)
	var lines: PackedStringArray = []
	if start > 0:
		lines.append("...  %d earlier missions" % start)
	for i in range(start, stop):
		var m: Dictionary = MISSIONS[i]
		var mark := "[ ]"
		var extra := ""
		if i < cur:
			mark = "[x]"
		elif i == cur:
			mark = "[>]"
			extra = "    %d/%d" % [_mission_value(m), int(m["goal"])]
		lines.append("%s  %d. %s%s" % [mark, i + 1, m["title"], extra])
	if stop < total:
		lines.append("...  %d more to come" % (total - stop))
	return "\n".join(lines)


func achievement_lines() -> String:
	var lines: PackedStringArray = []
	for i in ACH_IDS.size():
		var mark := "[ ]"
		if state.unlocked.has(ACH_IDS[i]):
			mark = "[x]"
		lines.append("%s  %s - %s" % [mark, ACH_TITLES[i], ACH_DESCS[i]])
	return "\n".join(lines)


func _process(delta: float) -> void:
	if state == null:
		return
	_timer += delta
	if _timer < 1.5:
		return
	_timer = 0.0
	if city != null and rickshaw != null:
		var gp: Vector3 = rickshaw.global_position
		var zone: int = city.zone_index_at(gp)
		state.zones_seen = int(state.zones_seen) | (1 << zone)
	_check_mission()
	_check_achievements()


func _on_trip_started() -> void:
	_crashes = 0
	_fines_this_trip = 0


func _on_crashed(_strength: float) -> void:
	_crashes += 1


## Called by main when the player gets a fine.
func on_fine() -> void:
	_fines_this_trip += 1
	_lawful_streak = 0
	if state.mission_index < MISSIONS.size():
		var m: Dictionary = MISSIONS[state.mission_index]
		if m["kind"] == "lawful":
			state.mission_progress = 0


## Called by main when the player grabs a street snack.
func on_food() -> void:
	state.foods += 1
	if state.mission_index < MISSIONS.size():
		var m: Dictionary = MISSIONS[state.mission_index]
		if m["kind"] == "food":
			state.mission_progress += 1
	_check_mission()
	_check_achievements()


func _is_rush() -> bool:
	if weather == null:
		return false
	var h: float = weather.hour
	return (h >= 8.0 and h < 10.0) or (h >= 17.0 and h < 19.5)


func _on_trip_finished(info: Dictionary) -> void:
	var rain_now := 0.0
	var night_now := 0.0
	if weather != null:
		rain_now = float(weather.rain)
		night_now = float(weather.night)
	if rain_now > 0.2:
		state.rain_trips += 1
	if night_now > 0.5:
		state.night_trips += 1
	var clean := _crashes == 0
	if clean:
		_clean_streak += 1
	else:
		_clean_streak = 0
	var no_fine := _fines_this_trip == 0
	if no_fine:
		_lawful_streak += 1
	_last_tip = int(info["tip"])
	var ratio := float(info["ratio"])
	var paid := int(info["paid"])
	var ptype := int(info["ptype"])

	if state.mission_index < MISSIONS.size():
		var m: Dictionary = MISSIONS[state.mission_index]
		var kind: String = m["kind"]
		var hit := false
		if kind == "trips":
			hit = true
		elif kind == "tips":
			hit = _last_tip > 0
		elif kind == "rain":
			hit = rain_now > 0.2
		elif kind == "clean":
			hit = clean
		elif kind == "night":
			hit = night_now > 0.5
		elif kind == "nightrain":
			hit = night_now > 0.5 and rain_now > 0.2
		elif kind == "fast":
			hit = ratio >= 0.5
		elif kind == "fastclean":
			hit = ratio >= 0.5 and clean
		elif kind == "rush":
			hit = _is_rush()
		elif kind == "bigfare":
			hit = paid >= 160
		elif kind == "streak":
			if ratio >= 0.0:
				state.mission_progress += 1
			else:
				state.mission_progress = 0
		elif kind == "lawful":
			if no_fine:
				state.mission_progress += 1
			else:
				state.mission_progress = 0
		elif kind.begins_with("type"):
			hit = ptype == int(kind.substr(4))
		elif kind.begins_with("zone"):
			var dest: Vector3 = info["dest"]
			hit = city != null and city.zone_index_at(dest) == int(kind.substr(4))
		if hit:
			state.mission_progress += 1
	_check_mission()
	_check_achievements()
	state.save_game()


func _mission_value(m: Dictionary) -> int:
	var kind: String = m["kind"]
	var goal := int(m["goal"])
	if kind == "cash":
		return mini(int(state.money), goal)
	if kind == "total":
		return mini(int(state.trips), goal)
	return mini(int(state.mission_progress), goal)


func _check_mission() -> void:
	if state.mission_index >= MISSIONS.size():
		return
	var m: Dictionary = MISSIONS[state.mission_index]
	if _mission_value(m) < int(m["goal"]):
		return
	state.money += int(m["reward"])
	state.mission_index += 1
	state.mission_progress = 0
	message.emit("Mission complete: %s|Reward Tk %d" % [m["title"], int(m["reward"])])
	sfx.emit("achievement")
	if state.mission_index >= MISSIONS.size():
		message.emit("Story complete!|Rahim made it in Dhaka. Keep driving!")
	else:
		announce()
	state.save_game()


func _ach_ok(id: String) -> bool:
	if id == "first_fare":
		return int(state.trips) >= 1
	if id == "regular":
		return int(state.trips) >= 25
	if id == "veteran":
		return int(state.trips) >= 100
	if id == "big_tip":
		return _last_tip >= 40
	if id == "rain_rider":
		return int(state.rain_trips) >= 5
	if id == "night_owl":
		return int(state.night_trips) >= 5
	if id == "rich":
		return int(state.money) >= 5000
	if id == "tuned":
		for lv in state.levels:
			if int(lv) < 1:
				return false
		return true
	if id == "explorer":
		return int(state.zones_seen) == 15
	if id == "smooth":
		return _clean_streak >= 5
	if id == "foodie":
		return int(state.foods) >= 30
	if id == "lawful":
		return _lawful_streak >= 10
	if id == "maxed":
		for lv in state.levels:
			if int(lv) >= 5:
				return true
		return false
	return false


func _check_achievements() -> void:
	for i in ACH_IDS.size():
		var id: String = ACH_IDS[i]
		if state.unlocked.has(id):
			continue
		if _ach_ok(id):
			state.unlocked.append(id)
			state.money += ACH_REWARDS[i]
			message.emit("Achievement: %s|%s - Tk %d" % [ACH_TITLES[i], ACH_DESCS[i], ACH_REWARDS[i]])
			sfx.emit("achievement")
			state.save_game()
