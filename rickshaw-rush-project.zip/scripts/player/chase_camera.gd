extends Camera3D
## Third-person chase camera. Sits behind and above the rickshaw, swings round
## smoothly in turns, and pulls back with a wider view as speed rises.

const DIST_NEAR := 6.6
const DIST_FAR := 8.2
const HEIGHT_NEAR := 3.2
const HEIGHT_FAR := 3.8
const FOV_NEAR := 62.0
const FOV_FAR := 74.0
const TOP_SPEED := 11.0

var target = null      # the rickshaw (needs: yaw, forward_speed)
var _yaw := 0.0
var _initialized := false


func _ready() -> void:
	near = 0.1
	far = 200.0
	fov = FOV_NEAR


func snap() -> void:
	_initialized = false


func _physics_process(delta: float) -> void:
	if target == null:
		return
	var first := not _initialized
	if first:
		_yaw = target.yaw
		_initialized = true

	var ratio := clampf(absf(target.forward_speed) / TOP_SPEED, 0.0, 1.0)
	_yaw = lerp_angle(_yaw, target.yaw, 1.0 - exp(-3.2 * delta))

	var dist := lerpf(DIST_NEAR, DIST_FAR, ratio)
	var height := lerpf(HEIGHT_NEAR, HEIGHT_FAR, ratio)
	var anchor: Vector3 = target.global_position
	var behind := Vector3(sin(_yaw), 0.0, cos(_yaw)) * dist
	global_position = anchor + behind + Vector3(0.0, height, 0.0)

	var ahead := Vector3(-sin(_yaw), 0.0, -cos(_yaw)) * 3.0
	look_at(anchor + Vector3(0.0, 1.0, 0.0) + ahead, Vector3.UP)

	fov = lerpf(fov, lerpf(FOV_NEAR, FOV_FAR, ratio), 1.0 - exp(-4.0 * delta))

	if first:
		reset_physics_interpolation()
