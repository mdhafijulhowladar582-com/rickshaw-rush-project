extends RefCounted
## Real houses for the Dhanmondi area. city.gd asks this helper for every plot there;
## if the models are missing city.gd simply keeps its plain boxes.

const DIR := "res://assets/models/houses/"
const MAX_W := 14.7           # widest house in metres at scale 1

var count := 0

var _lib = null
var _meshes: Array = []
var _xf: Dictionary = {}


func setup() -> bool:
	var s = load("res://scripts/world/model_lib.gd")
	if s == null or not s.can_instantiate():
		return false
	_lib = s.new()
	for c in "abcdefghij":
		var m = _lib.mesh(DIR + "building-type-" + c + ".glb")
		if m != null:
			_meshes.append(m)
	return _meshes.size() >= 3


func add_house(bx: int, bz: int, cx: float, cz: float, plot: float, base_y: float, rng: RandomNumberGenerator) -> void:
	var idx := rng.randi() % _meshes.size()
	var yaw := float(rng.randi() % 4) * PI * 0.5
	var f := plot * 0.92 / MAX_W
	var basis := Basis(Vector3.UP, yaw).scaled(Vector3(f, f, f))
	var key := Vector3i(bx / 3, bz / 3, idx)
	var list: Array = _xf.get(key, [])
	list.append(Transform3D(basis, Vector3(cx, base_y, cz)))
	_xf[key] = list
	count += 1


func finish(parent: Node) -> void:
	for key in _xf:
		var k: Vector3i = key
		_lib.add_multimesh(parent, _meshes[k.z], _xf[key], 260.0)
