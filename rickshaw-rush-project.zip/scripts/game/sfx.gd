extends Node
## Background music and short one-shot sounds. Runs while the game is paused so the
## menus have music and click sounds too. Sound effects by Kenney (CC0).

const SOUNDS := {
	"click": "res://assets/audio/kenney/click_003.ogg",
	"back": "res://assets/audio/kenney/back_002.ogg",
	"coin": "res://assets/audio/kenney/confirmation_002.ogg",
	"achievement": "res://assets/audio/kenney/powerUp8.ogg",
	"fine": "res://assets/audio/kenney/error_002.ogg",
	"whistle": "res://assets/audio/whistle.wav",
}

var _music: AudioStreamPlayer
var _players: Dictionary = {}


func setup() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	add_to_group("sfx")
	_music = AudioStreamPlayer.new()
	_music.volume_db = -17.0
	add_child(_music)
	var path := "res://assets/audio/music_loop.wav"
	if ResourceLoader.exists(path):
		var stream = load(path)
		if stream is AudioStreamWAV:
			stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
			stream.loop_begin = 0
			stream.loop_end = int(stream.data.size() / 2)
		_music.stream = stream
		_music.play()
	for key in SOUNDS:
		var p := AudioStreamPlayer.new()
		p.volume_db = -4.0
		var spath: String = SOUNDS[key]
		if ResourceLoader.exists(spath):
			p.stream = load(spath)
		add_child(p)
		_players[key] = p


func set_music(on: bool) -> void:
	if _music == null or _music.stream == null:
		return
	if on and not _music.playing:
		_music.play()
	elif not on and _music.playing:
		_music.stop()


func play(sound: String) -> void:
	if not _players.has(sound):
		return
	var p: AudioStreamPlayer = _players[sound]
	if p.stream != null:
		p.play()
