extends Node
## Story missions, achievements and the counters behind them.

signal message(text: String)
signal sfx(sound: String)

const MISSIONS: Array = [
	{"title": "First day", "story": "Rahim just arrived in Dhaka.|Earn your first fares.", "kind": "trips", "goal": 3, "reward": 100},
	{"title": "Mind the clock", "story": "Fast drivers earn tips.|Get a tip on 2 trips.", "kind": "tips", "goal": 2, "reward": 120},
	{"title": "Rainy days", "story": "Rain keeps the buses away.|Finish 3 trips in the rain.", "kind": "rain", "goal": 3, "reward": 200},
	{"title": "Careful driver", "story": "Careful drivers get more rides.|Finish 3 trips without a crash.", "kind": "clean", "goal": 3, "reward": 200},
	{"title": "Old Dhaka run", "story": "Narrow lanes and big crowds.|Drop 3 passengers in Old Dhaka.", "kind": "zone0", "goal": 3, "reward": 250},
	{"title": "Night shift", "story": "The city never sleeps.|Finish 3 trips at night.", "kind": "night", "goal": 3, "reward": 300},
	{"title": "Tourist guide", "story": "Visitors want to see Dhaka.|Carry 3 tourists.", "kind": "tourist", "goal": 3, "reward": 300},
	{"title": "Express", "story": "Some rides cannot wait.|Deliver 3 trips with half the time left.", "kind": "fast", "goal": 3, "reward": 400},
	{"title": "Savings", "story": "Mother needs money back home.|Hold Tk 2000 at once.", "kind": "cash", "goal": 2000, "reward": 500},
	{"title": "King of the road", "story": "All of Dhaka knows your bell.|Finish 25 trips in total.", "kind": "total", "goal": 25, "reward": 800},
]

const ACH_IDS: Array[String] = ["first_fare", "regular", "veteran", "big_tip", "rain_rider", "night_owl", "rich", "tuned", "explorer", "smooth"]
const ACH_TITLES: Array[String] = ["First fare", "Regular", "Veteran", "Big tipper", "Rain rider", "Night owl", "Rich", "Tuned up", "Explorer", "Smooth ride"]
const ACH_DESCS: Array[String] = [
	"Finish a trip", "Finish 25 trips", "Finish 100 trips", "Get a tip of Tk 40 or more",
	"Finish 5 trips in the rain", "Finish 5 trips at night", "Hold Tk 3000 at once",
	"Buy one of every upgrade", "Visit all four areas", "5 trips in a row without a crash",
]
const ACH_REWARDS: Array[int] = [20, 100, 400, 100, 150, 150, 300, 150, 150, 200]

var state = null
var trips = null
var rickshaw = null
var weather = null
var city = null

var _crashes := 0
var _clean_streak := 0
var _last_tip := 0
var _timer := 0.0


func setup(s, t, r, w, c) -> void:
	state = s
	trips = t
	rickshaw = r
	weather = w
	city = c
	trips.trip_started.connect(_on_trip_started)
	trips.trip_finished.connect(_on_trip_finished)
	rickshaw.crashed.connect(_on_crashed)


## Tell the player what the current mission is (called once the HUD exists).
func announce() -> void:
	if state.mission_index >= MISSIONS.size():
		return
	var m: Dictionary = MISSIONS[state.mission_index]
	message.emit("Mission %d: %s|%s" % [int(state.mission_index) + 1, m["title"], m["story"]])


func mission_text() -> String:
	if state == null:
		return ""
	if state.mission_index >= MISSIONS.size():
		return "All missions complete!"
	var m: Dictionary = MISSIONS[state.mission_index]
	return "Mission %d: %s   %d/%d" % [int(state.mission_index) + 1, m["title"], _mission_value(m), int(m["goal"])]


func mission_lines() -> String:
	var lines: PackedStringArray = []
	for i in MISSIONS.size():
		var m: Dictionary = MISSIONS[i]
		var mark := "[ ]"
		var extra := ""
		if i < int(state.mission_index):
			mark = "[x]"
		elif i == int(state.mission_index):
			mark = "[>]"
			extra = "    %d/%d" % [_mission_value(m), int(m["goal"])]
		lines.append("%s  %d. %s%s" % [mark, i + 1, m["title"], extra])
	return "\n".join(lines)


func achievement_lines() -> String:
	var lines: PackedStringArray = []
	for i in ACH_IDS.size():
		var mark := "[ ]"
		if state.unlocked.has(ACH_IDS[i]):
			mark = "[x]"
		lines.append("%s  %s - %s" % [mark, ACH_TITLES[i], ACH_DESCS[i]])
	return "\n".join(lines)


func _process(delta: float) -> void:
	if state == null:
		return
	_timer += delta
	if _timer < 1.5:
		return
	_timer = 0.0
	if city != null and rickshaw != null:
		var gp: Vector3 = rickshaw.global_position
		var zone: int = city.zone_index_at(gp)
		state.zones_seen = int(state.zones_seen) | (1 << zone)
	_check_mission()
	_check_achievements()


func _on_trip_started() -> void:
	_crashes = 0


func _on_crashed(_strength: float) -> void:
	_crashes += 1


func _on_trip_finished(info: Dictionary) -> void:
	var rain_now := 0.0
	var night_now := 0.0
	if weather != null:
		rain_now = float(weather.rain)
		night_now = float(weather.night)
	if rain_now > 0.2:
		state.rain_trips += 1
	if night_now > 0.5:
		state.night_trips += 1
	var clean := _crashes == 0
	if clean:
		_clean_streak += 1
	else:
		_clean_streak = 0
	_last_tip = int(info["tip"])

	if state.mission_index < MISSIONS.size():
		var m: Dictionary = MISSIONS[state.mission_index]
		var kind: String = m["kind"]
		var hit := false
		if kind == "trips":
			hit = true
		elif kind == "tips":
			hit = int(info["tip"]) > 0
		elif kind == "rain":
			hit = rain_now > 0.2
		elif kind == "clean":
			hit = clean
		elif kind == "night":
			hit = night_now > 0.5
		elif kind == "tourist":
			hit = int(info["ptype"]) == 3
		elif kind == "fast":
			hit = float(info["ratio"]) >= 0.5
		elif kind.begins_with("zone"):
			var dest: Vector3 = info["dest"]
			hit = city != null and city.zone_index_at(dest) == int(kind.substr(4))
		if hit:
			state.mission_progress += 1
	_check_mission()
	_check_achievements()
	state.save_game()


func _mission_value(m: Dictionary) -> int:
	var kind: String = m["kind"]
	var goal := int(m["goal"])
	if kind == "cash":
		return mini(int(state.money), goal)
	if kind == "total":
		return mini(int(state.trips), goal)
	return mini(int(state.mission_progress), goal)


func _check_mission() -> void:
	if state.mission_index >= MISSIONS.size():
		return
	var m: Dictionary = MISSIONS[state.mission_index]
	if _mission_value(m) < int(m["goal"]):
		return
	state.money += int(m["reward"])
	state.mission_index += 1
	state.mission_progress = 0
	message.emit("Mission complete: %s|Reward Tk %d" % [m["title"], int(m["reward"])])
	sfx.emit("achievement")
	if state.mission_index >= MISSIONS.size():
		message.emit("Story complete!|Rahim made it in Dhaka. Keep driving!")
	else:
		announce()
	state.save_game()


func _ach_ok(id: String) -> bool:
	if id == "first_fare":
		return int(state.trips) >= 1
	if id == "regular":
		return int(state.trips) >= 25
	if id == "veteran":
		return int(state.trips) >= 100
	if id == "big_tip":
		return _last_tip >= 40
	if id == "rain_rider":
		return int(state.rain_trips) >= 5
	if id == "night_owl":
		return int(state.night_trips) >= 5
	if id == "rich":
		return int(state.money) >= 3000
	if id == "tuned":
		for lv in state.levels:
			if int(lv) < 1:
				return false
		return true
	if id == "explorer":
		return int(state.zones_seen) == 15
	if id == "smooth":
		return _clean_streak >= 5
	return false


func _check_achievements() -> void:
	for i in ACH_IDS.size():
		var id: String = ACH_IDS[i]
		if state.unlocked.has(id):
			continue
		if _ach_ok(id):
			state.unlocked.append(id)
			state.money += ACH_REWARDS[i]
			message.emit("Achievement: %s|%s - Tk %d" % [ACH_TITLES[i], ACH_DESCS[i], ACH_REWARDS[i]])
			sfx.emit("achievement")
			state.save_game()
