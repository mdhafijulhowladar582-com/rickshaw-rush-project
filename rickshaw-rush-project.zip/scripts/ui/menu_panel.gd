extends Control
## Title screen, pause menu, settings, missions, achievements and how-to-play pages.
## The game is paused while this is visible, so everything here runs in "always" mode.

signal play_pressed
signal resume_pressed
signal garage_pressed
signal settings_changed
signal reset_requested
signal daily_claimed(amount: int)

const QUALITY_NAMES: Array[String] = ["Low", "Medium", "High"]
const HELP_TITLES: Array[String] = ["Driving", "Earning money", "Garage and tips", "Traffic rules"]
const HELP_TEXTS: Array[String] = [
	"Drag on the left side of the screen to steer, and pull down to brake. Hold PEDAL to pedal and tap BELL to ring the bell. Pedalling hard uses stamina, so ease off now and then to recover.",
	"Drive to the yellow marker and slow down inside the circle to pick up a passenger. Then follow the arrow to the green marker. Arrive early for a tip - arrive late and the fare drops.",
	"Open GARAGE to spend your cash on tires, a smoother chain, stronger legs, a comfy seat or a new hood colour. Missions and achievements pay bonus cash. Claim your daily reward on the title screen.",
	"Stop at red lights - running one costs a Tk 40 fine. Police cars fine you for speeding right past them. Rush hours fill the roads, and rain makes them slippery.",
]

var state = null
var progress = null
var is_title := true

var _pages: Dictionary = {}
var _page := ""
var _progress_label: Label
var _daily_btn: Button
var _play_btn: Button
var _vol_label: Label
var _music_btn: Button
var _quality_btn: Button
var _stats_btn: Button
var _reset_btn: Button
var _reset_armed := false
var _help_title: Label
var _help_body: Label
var _help_count: Label
var _help_next: Button
var _help_index := 0
var _help_then_play := false
var _missions_story: Label
var _missions_list: Label
var _ach_list: Label


func setup(s) -> void:
	state = s
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	mouse_filter = Control.MOUSE_FILTER_STOP
	_build()


func open_title() -> void:
	is_title = true
	_show_page("title")
	visible = true


func open_pause() -> void:
	is_title = false
	_show_page("pause")
	visible = true


## Android back button or Esc while the menu is open.
func back() -> void:
	if _page == "settings" or _page == "help" or _page == "missions" or _page == "achievements":
		_back_to_main_page()
	elif _page == "pause":
		_on_resume()


func _build() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0.0, 0.0, 0.0, 0.55)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center := CenterContainer.new()
	add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(560.0, 0.0)
	center.add_child(panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 24)
	margin.add_theme_constant_override("margin_right", 24)
	margin.add_theme_constant_override("margin_top", 16)
	margin.add_theme_constant_override("margin_bottom", 16)
	panel.add_child(margin)

	_pages["title"] = _build_title()
	_pages["pause"] = _build_pause()
	_pages["settings"] = _build_settings()
	_pages["help"] = _build_help()
	_pages["missions"] = _build_missions()
	_pages["achievements"] = _build_achievements()
	# Pages share one slot: only the visible one takes up space.
	for key in _pages:
		var page: Control = _pages[key]
		margin.add_child(page)
		page.visible = false


func _new_page() -> VBoxContainer:
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	return vb


func _label(text: String, size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


func _button(text: String, callback: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0.0, 52.0)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(callback)
	b.pressed.connect(_click)
	return b


func _row(a: Button, b: Button) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 10)
	h.add_child(a)
	h.add_child(b)
	return h


func _click() -> void:
	get_tree().call_group("sfx", "play", "click")


func _build_title() -> VBoxContainer:
	var vb := _new_page()
	vb.add_child(_label("RICKSHAW RUSH", 52, Color(1.0, 0.85, 0.3)))
	vb.add_child(_label("Drive. Earn. Upgrade.", 20, Color(1.0, 1.0, 1.0, 0.75)))
	_progress_label = _label("", 18, Color(0.7, 0.95, 0.8))
	vb.add_child(_progress_label)
	_daily_btn = _button("", _on_daily)
	vb.add_child(_daily_btn)
	_play_btn = _button("Play", _on_play)
	vb.add_child(_play_btn)
	vb.add_child(_row(_button("Missions", _show_page.bind("missions")), _button("Achievements", _show_page.bind("achievements"))))
	vb.add_child(_row(_button("How to play", _open_help.bind(false)), _button("Settings", _show_page.bind("settings"))))
	vb.add_child(_button("Quit", _on_quit))
	return vb


func _build_pause() -> VBoxContainer:
	var vb := _new_page()
	vb.add_child(_label("PAUSED", 40, Color(1.0, 0.85, 0.3)))
	vb.add_child(_button("Resume", _on_resume))
	vb.add_child(_button("Garage", _on_garage))
	vb.add_child(_row(_button("Missions", _show_page.bind("missions")), _button("Achievements", _show_page.bind("achievements"))))
	vb.add_child(_row(_button("How to play", _open_help.bind(false)), _button("Settings", _show_page.bind("settings"))))
	vb.add_child(_button("Main menu", open_title))
	return vb


func _build_settings() -> VBoxContainer:
	var vb := _new_page()
	vb.add_child(_label("SETTINGS", 36, Color(1.0, 0.85, 0.3)))

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	vb.add_child(row)
	var name_label := Label.new()
	name_label.text = "Sound volume"
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(name_label)
	var minus := _button("-", _on_volume.bind(-0.1))
	minus.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	minus.custom_minimum_size = Vector2(64.0, 52.0)
	row.add_child(minus)
	_vol_label = Label.new()
	_vol_label.custom_minimum_size = Vector2(70.0, 0.0)
	_vol_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	row.add_child(_vol_label)
	var plus := _button("+", _on_volume.bind(0.1))
	plus.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	plus.custom_minimum_size = Vector2(64.0, 52.0)
	row.add_child(plus)

	_music_btn = _button("", _on_music)
	vb.add_child(_music_btn)
	_quality_btn = _button("", _on_quality)
	vb.add_child(_quality_btn)
	_stats_btn = _button("", _on_stats)
	vb.add_child(_stats_btn)
	_reset_btn = _button("", _on_reset)
	vb.add_child(_reset_btn)
	vb.add_child(_button("Back", _back_to_main_page))
	return vb


func _build_help() -> VBoxContainer:
	var vb := _new_page()
	_help_title = _label("", 32, Color(1.0, 0.85, 0.3))
	vb.add_child(_help_title)
	_help_body = Label.new()
	_help_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_help_body.custom_minimum_size = Vector2(500.0, 130.0)
	_help_body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_child(_help_body)
	_help_count = _label("", 16, Color(1.0, 1.0, 1.0, 0.6))
	vb.add_child(_help_count)
	_help_next = _button("Next", _on_help_next)
	vb.add_child(_help_next)
	return vb


func _build_missions() -> VBoxContainer:
	var vb := _new_page()
	vb.add_child(_label("MISSIONS", 36, Color(1.0, 0.85, 0.3)))
	_missions_story = _label("", 16, Color(0.7, 0.95, 0.8))
	vb.add_child(_missions_story)
	_missions_list = Label.new()
	_missions_list.add_theme_font_size_override("font_size", 18)
	vb.add_child(_missions_list)
	vb.add_child(_button("Back", _back_to_main_page))
	return vb


func _build_achievements() -> VBoxContainer:
	var vb := _new_page()
	vb.add_child(_label("ACHIEVEMENTS", 36, Color(1.0, 0.85, 0.3)))
	_ach_list = Label.new()
	_ach_list.add_theme_font_size_override("font_size", 18)
	vb.add_child(_ach_list)
	vb.add_child(_button("Back", _back_to_main_page))
	return vb


func _show_page(page: String) -> void:
	_page = page
	_reset_armed = false
	_refresh()
	for key in _pages:
		var p: Control = _pages[key]
		p.visible = (key == page)


func _back_to_main_page() -> void:
	if is_title:
		_show_page("title")
	else:
		_show_page("pause")


func _refresh() -> void:
	if state == null:
		return
	var trips: int = state.trips
	if trips > 0:
		_progress_label.text = "Cash Tk %d   -   %d trips done" % [int(state.money), trips]
		_play_btn.text = "Continue"
	else:
		_progress_label.text = "Welcome, driver!"
		_play_btn.text = "Play"
	_daily_btn.visible = state.daily_available()
	_daily_btn.text = "Claim daily reward: +Tk %d" % int(state.daily_amount())
	_vol_label.text = "%d%%" % roundi(float(state.volume) * 100.0)
	if state.music_on:
		_music_btn.text = "Music: On"
	else:
		_music_btn.text = "Music: Off"
	_quality_btn.text = "Graphics: " + QUALITY_NAMES[int(state.quality)]
	if state.show_stats:
		_stats_btn.text = "FPS and stats: On"
	else:
		_stats_btn.text = "FPS and stats: Off"
	if _reset_armed:
		_reset_btn.text = "Tap again to erase progress"
	else:
		_reset_btn.text = "Reset progress"

	if progress != null:
		_missions_list.text = progress.mission_lines()
		_ach_list.text = progress.achievement_lines()
		_missions_story.text = progress.mission_text()
	else:
		_missions_list.text = "Not available"
		_ach_list.text = "Not available"
		_missions_story.text = ""


func _on_daily() -> void:
	var amount: int = state.claim_daily()
	if amount > 0:
		daily_claimed.emit(amount)
	_refresh()


func _on_play() -> void:
	if not state.tutorial_done:
		_open_help(true)
	else:
		visible = false
		play_pressed.emit()


func _on_resume() -> void:
	visible = false
	resume_pressed.emit()


func _on_garage() -> void:
	visible = false
	garage_pressed.emit()


func _on_quit() -> void:
	state.save_game()
	get_tree().quit()


func _on_volume(step: float) -> void:
	state.volume = clampf(snappedf(float(state.volume) + step, 0.1), 0.0, 1.0)
	state.save_game()
	_refresh()
	settings_changed.emit()


func _on_music() -> void:
	state.music_on = not state.music_on
	state.save_game()
	_refresh()
	settings_changed.emit()


func _on_quality() -> void:
	state.quality = (int(state.quality) + 1) % QUALITY_NAMES.size()
	state.save_game()
	_refresh()
	settings_changed.emit()


func _on_stats() -> void:
	state.show_stats = not state.show_stats
	state.save_game()
	_refresh()
	settings_changed.emit()


func _on_reset() -> void:
	if not _reset_armed:
		_reset_armed = true
		_refresh()
		return
	_reset_armed = false
	state.reset_progress()
	_refresh()
	reset_requested.emit()


func _open_help(then_play: bool) -> void:
	_help_then_play = then_play
	_help_index = 0
	_update_help()
	_show_page("help")


func _update_help() -> void:
	_help_title.text = HELP_TITLES[_help_index]
	_help_body.text = HELP_TEXTS[_help_index]
	_help_count.text = "%d / %d" % [_help_index + 1, HELP_TEXTS.size()]
	if _help_index < HELP_TEXTS.size() - 1:
		_help_next.text = "Next"
	elif _help_then_play:
		_help_next.text = "Let's go!"
	else:
		_help_next.text = "Done"


func _on_help_next() -> void:
	if _help_index < HELP_TEXTS.size() - 1:
		_help_index += 1
		_update_help()
		return
	state.tutorial_done = true
	state.save_game()
	if _help_then_play:
		_help_then_play = false
		visible = false
		play_pressed.emit()
	else:
		_back_to_main_page()
