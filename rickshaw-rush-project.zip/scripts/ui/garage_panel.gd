extends Control
## Garage: spend cash on upgrades and repaint the hood. The game is paused while it is open.

signal changed
signal closed

const GameStateScript = preload("res://scripts/game/game_state.gd")

var state = null

var _cash_label: Label
var _rows: Array[Label] = []
var _buttons: Array[Button] = []
var _paint_btn: Button


func setup(s) -> void:
	state = s
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	mouse_filter = Control.MOUSE_FILTER_STOP
	_build()


func open() -> void:
	visible = true
	refresh()


func close() -> void:
	_on_close()


func _build() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0.0, 0.0, 0.0, 0.6)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center := CenterContainer.new()
	add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(640.0, 0.0)
	center.add_child(panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 18)
	margin.add_theme_constant_override("margin_right", 18)
	margin.add_theme_constant_override("margin_top", 12)
	margin.add_theme_constant_override("margin_bottom", 12)
	panel.add_child(margin)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	margin.add_child(vb)

	var title := Label.new()
	title.text = "GARAGE"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 28)
	vb.add_child(title)

	_cash_label = Label.new()
	_cash_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_cash_label.add_theme_font_size_override("font_size", 22)
	_cash_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.3))
	vb.add_child(_cash_label)

	for i in GameStateScript.UP_NAMES.size():
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		vb.add_child(row)

		var lab := Label.new()
		lab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		lab.add_theme_font_size_override("font_size", 18)
		row.add_child(lab)
		_rows.append(lab)

		var btn := Button.new()
		btn.custom_minimum_size = Vector2(170.0, 46.0)
		btn.focus_mode = Control.FOCUS_NONE
		btn.pressed.connect(_on_buy.bind(i))
		row.add_child(btn)
		_buttons.append(btn)

	var prow := HBoxContainer.new()
	prow.add_theme_constant_override("separation", 10)
	vb.add_child(prow)
	var plab := Label.new()
	plab.text = "Repaint hood\nPick the next colour"
	plab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	plab.add_theme_font_size_override("font_size", 18)
	prow.add_child(plab)
	_paint_btn = Button.new()
	_paint_btn.custom_minimum_size = Vector2(170.0, 46.0)
	_paint_btn.focus_mode = Control.FOCUS_NONE
	_paint_btn.pressed.connect(_on_repaint)
	prow.add_child(_paint_btn)

	var close := Button.new()
	close.text = "Close"
	close.custom_minimum_size = Vector2(0.0, 50.0)
	close.focus_mode = Control.FOCUS_NONE
	close.pressed.connect(_on_close)
	vb.add_child(close)


func refresh() -> void:
	_cash_label.text = "Cash: Tk %d" % int(state.money)
	for i in _rows.size():
		var lv: int = state.levels[i]
		_rows[i].text = "%s   [Lv %d/%d]\n%s" % [GameStateScript.UP_NAMES[i], lv, GameStateScript.MAX_LEVEL, GameStateScript.UP_DESCS[i]]
		var cost: int = state.upgrade_cost(i)
		if cost < 0:
			_buttons[i].text = "MAX"
			_buttons[i].disabled = true
		else:
			_buttons[i].text = "Buy  Tk %d" % cost
			_buttons[i].disabled = int(state.money) < cost
	_paint_btn.text = "Repaint  Tk %d" % GameStateScript.PAINT_COST
	_paint_btn.disabled = int(state.money) < GameStateScript.PAINT_COST


func _on_buy(i: int) -> void:
	get_tree().call_group("sfx", "play", "click")
	if state.try_buy(i):
		changed.emit()
	refresh()


func _on_repaint() -> void:
	get_tree().call_group("sfx", "play", "click")
	if state.try_repaint():
		changed.emit()
	refresh()


func _on_close() -> void:
	get_tree().call_group("sfx", "play", "back")
	visible = false
	closed.emit()
