extends Node3D
## Passenger jobs: wait for a passenger at the yellow marker, drive them to the
## green marker, get paid. Faster trips earn tips, late trips lose part of the fare.

signal message(text: String)
signal trip_started
signal trip_finished(info: Dictionary)

const CityScript = preload("res://scripts/world/city.gd")

const PH_WAIT := 0
const PH_TRIP := 1
const PH_NONE := 2

const PICK_RADIUS := 5.5
const DROP_RADIUS := 6.0
const MAX_STOP_SPEED := 5.0

const TYPE_NAMES: Array[String] = ["Student", "Office worker", "Shopper", "Tourist", "Elderly uncle"]
const TYPE_FARE: Array[float] = [1.0, 1.3, 1.0, 1.4, 1.0]
const TYPE_TIME: Array[float] = [1.15, 0.8, 1.0, 1.25, 1.3]
const TYPE_COLORS: Array[Color] = [
	Color(0.25, 0.45, 0.85), Color(0.85, 0.85, 0.88), Color(0.85, 0.35, 0.50),
	Color(0.30, 0.75, 0.45), Color(0.65, 0.55, 0.40),
]

var rickshaw = null
var city = null
var state = null

var phase := PH_NONE
var pickup_pos := Vector3.ZERO
var dest_pos := Vector3.ZERO
var passenger_type := 0
var route_dist := 0.0
var time_allowed := 1.0
var time_left := 0.0
var base_fare := 0
var distance := 0.0

var _cooldown := 0.0
var _hint_cooldown := 0.0
var _rng := RandomNumberGenerator.new()
var _pickup_marker: Node3D
var _dest_marker: Node3D
var _figure_mat: StandardMaterial3D
var _models = null
var _fig_nodes: Array[Node3D] = []


func setup(r, c, s) -> void:
	rickshaw = r
	city = c
	state = s
	_rng.randomize()
	_pickup_marker = _make_marker(Color(1.0, 0.85, 0.15), true)
	_dest_marker = _make_marker(Color(0.25, 0.95, 0.40), false)
	add_child(_pickup_marker)
	add_child(_dest_marker)
	_models = _make_passenger_models()
	_pickup_marker.visible = false
	_dest_marker.visible = false


func start() -> void:
	_new_passenger()


func passenger_name() -> String:
	return TYPE_NAMES[passenger_type]


func target_position() -> Vector3:
	if phase == PH_WAIT:
		return pickup_pos
	return dest_pos


func _physics_process(delta: float) -> void:
	if rickshaw == null:
		return
	_hint_cooldown = maxf(_hint_cooldown - delta, 0.0)

	if phase == PH_NONE:
		_cooldown -= delta
		if _cooldown <= 0.0:
			_new_passenger()
		return

	var rp: Vector3 = rickshaw.global_position
	var speed: float = absf(rickshaw.forward_speed)
	var target := target_position()
	distance = Vector2(rp.x - target.x, rp.z - target.z).length()

	if phase == PH_TRIP:
		time_left -= delta

	var radius := DROP_RADIUS
	if phase == PH_WAIT:
		radius = PICK_RADIUS
	if distance < radius:
		if speed < MAX_STOP_SPEED:
			if phase == PH_WAIT:
				_board()
			else:
				_deliver()
		elif _hint_cooldown <= 0.0:
			_hint_cooldown = 2.5
			message.emit("Slow down to stop here")


func _grid_index(v: float) -> int:
	return clampi(roundi(v / CityScript.PITCH + float(CityScript.BLOCKS) * 0.5), 0, CityScript.BLOCKS)


func _grid_pos(ix: int, iz: int) -> Vector3:
	var half := float(CityScript.BLOCKS) * 0.5
	return Vector3((float(ix) - half) * CityScript.PITCH, 0.0, (float(iz) - half) * CityScript.PITCH)


## A random road crossing between min_steps and max_steps blocks away (Manhattan distance).
func _pick_cell(from_x: int, from_z: int, min_steps: int, max_steps: int) -> Vector2i:
	for attempt in 40:
		var dx := _rng.randi_range(-max_steps, max_steps)
		var dz := _rng.randi_range(-max_steps, max_steps)
		var steps := absi(dx) + absi(dz)
		if steps < min_steps or steps > max_steps:
			continue
		var nx := from_x + dx
		var nz := from_z + dz
		if nx < 0 or nx > CityScript.BLOCKS or nz < 0 or nz > CityScript.BLOCKS:
			continue
		return Vector2i(nx, nz)
	var fx := from_x + min_steps
	if fx > CityScript.BLOCKS:
		fx = from_x - min_steps
	return Vector2i(fx, from_z)


func _new_passenger() -> void:
	var rp: Vector3 = rickshaw.global_position
	var cell := _pick_cell(_grid_index(rp.x), _grid_index(rp.z), 3, 8)
	pickup_pos = _grid_pos(cell.x, cell.y)
	passenger_type = _rng.randi() % TYPE_NAMES.size()
	phase = PH_WAIT
	_pickup_marker.position = pickup_pos
	_pickup_marker.reset_physics_interpolation()
	_pickup_marker.visible = true
	_dest_marker.visible = false
	if _figure_mat != null:
		_figure_mat.albedo_color = TYPE_COLORS[passenger_type]
	if _models != null:
		_models.show_type(passenger_type)
	rickshaw.set_passenger(false)
	message.emit("New passenger: %s. Drive to the yellow marker." % TYPE_NAMES[passenger_type])


func _board() -> void:
	var cell := _pick_cell(_grid_index(pickup_pos.x), _grid_index(pickup_pos.z), 4, 10)
	dest_pos = _grid_pos(cell.x, cell.y)
	route_dist = absf(dest_pos.x - pickup_pos.x) + absf(dest_pos.z - pickup_pos.z)
	time_allowed = (route_dist / 6.5 + 12.0) * TYPE_TIME[passenger_type]
	time_left = time_allowed
	base_fare = roundi((25.0 + route_dist * 0.25) * TYPE_FARE[passenger_type])
	phase = PH_TRIP
	_pickup_marker.visible = false
	_dest_marker.position = dest_pos
	_dest_marker.reset_physics_interpolation()
	_dest_marker.visible = true
	rickshaw.set_passenger(true, TYPE_COLORS[passenger_type])
	message.emit("%s on board. Fare about Tk %d. Reach the green marker in %d s." % [TYPE_NAMES[passenger_type], base_fare, int(time_allowed)])
	trip_started.emit()


func _deliver() -> void:
	var ratio := time_left / time_allowed
	var mult := clampf(1.0 + ratio, 0.6, 1.5)
	var seat: int = state.levels[3]
	var fare := float(base_fare)
	var total := fare * mult
	if mult > 1.0:
		total = fare + (mult - 1.0) * fare * (1.0 + 0.3 * float(seat))
	var paid := roundi(total)
	var diff := paid - base_fare

	state.money += paid
	state.trips += 1
	state.save_game()

	if diff > 0:
		message.emit("Delivered! Fare Tk %d + tip Tk %d" % [base_fare, diff])
	elif diff < 0:
		message.emit("Late! Fare cut to Tk %d" % paid)
	else:
		message.emit("Delivered! Tk %d" % paid)

	rickshaw.set_passenger(false)
	_dest_marker.visible = false
	phase = PH_NONE
	_cooldown = 3.0
	trip_finished.emit({"paid": paid, "tip": diff, "ptype": passenger_type, "ratio": ratio, "dest": dest_pos})


## Real passenger models instead of the capsule figure, if the model files are there.
func _make_passenger_models():
	var s = load("res://scripts/game/passenger_models.gd")
	var l = load("res://scripts/world/model_lib.gd")
	if s == null or l == null or not s.can_instantiate() or not l.can_instantiate():
		return null
	var m = s.new()
	_pickup_marker.add_child(m)
	if not m.setup(l.new()):
		m.queue_free()
		return null
	m.position = Vector3(2.2, 0.0, 0.0)
	for n in _fig_nodes:
		n.visible = false
	return m


func _make_marker(color: Color, with_figure: bool) -> Node3D:
	var root := Node3D.new()

	var beam := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 1.6
	cyl.bottom_radius = 1.6
	cyl.height = 45.0
	cyl.radial_segments = 16
	cyl.rings = 1
	beam.mesh = cyl
	beam.position = Vector3(0.0, 22.5, 0.0)
	beam.material_override = _glow_mat(Color(color.r, color.g, color.b, 0.22))
	beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(beam)

	var ring := MeshInstance3D.new()
	var disc := CylinderMesh.new()
	disc.top_radius = 4.2
	disc.bottom_radius = 4.2
	disc.height = 0.05
	disc.radial_segments = 24
	disc.rings = 1
	ring.mesh = disc
	ring.position = Vector3(0.0, 0.08, 0.0)
	ring.material_override = _glow_mat(Color(color.r, color.g, color.b, 0.45))
	ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(ring)

	if with_figure:
		_figure_mat = StandardMaterial3D.new()
		_figure_mat.albedo_color = Color.WHITE
		var skin := StandardMaterial3D.new()
		skin.albedo_color = Color(0.58, 0.40, 0.30)

		var body := MeshInstance3D.new()
		var capsule := CapsuleMesh.new()
		capsule.radius = 0.26
		capsule.height = 1.3
		capsule.radial_segments = 10
		capsule.rings = 3
		body.mesh = capsule
		body.material_override = _figure_mat
		body.position = Vector3(2.2, 0.7, 0.0)
		root.add_child(body)
		_fig_nodes.append(body)

		var head := MeshInstance3D.new()
		var ball := SphereMesh.new()
		ball.radius = 0.18
		ball.height = 0.36
		ball.radial_segments = 10
		ball.rings = 5
		head.mesh = ball
		head.material_override = skin
		head.position = Vector3(2.2, 1.55, 0.0)
		root.add_child(head)
		_fig_nodes.append(head)

	return root


func _glow_mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = c
	m.disable_fog = true
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	return m
