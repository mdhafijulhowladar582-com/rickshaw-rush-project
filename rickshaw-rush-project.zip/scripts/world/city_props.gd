extends Node3D
## Street furniture on the footpaths: lamps, electricity poles, trees, benches, dumpsters,
## cones, barriers and stop signs. How much of each depends on the area.

const CityScript = preload("res://scripts/world/city.gd")

const DIR := "res://assets/models/props/"
const CHUNK := 4              # blocks per draw-call group
const RANGE_END := 215.0
const SLAB_Y := 0.25

# chance per footpath edge (4 per block): tree, pole, bench, dumpster, cones
const TREE_P: Array[float] = [0.10, 0.30, 0.55, 0.22]
const POLE_P: Array[float] = [0.55, 0.20, 0.30, 0.40]
const BENCH_P: Array[float] = [0.04, 0.05, 0.10, 0.03]
const DUMP_P: Array[float] = [0.12, 0.03, 0.02, 0.12]
const CONE_P: Array[float] = [0.04, 0.07, 0.02, 0.12]
const TREES: Array[String] = ["sub_tree-large", "sub_tree-small", "retro_tree-large", "retro_tree-pine-large"]

var _lib = null
var _rng := RandomNumberGenerator.new()
var _groups: Dictionary = {}


func setup(city) -> void:
	var s = load("res://scripts/world/model_lib.gd")
	if s == null or not s.can_instantiate():
		return
	_lib = s.new()
	_rng.seed = 4242
	var n: int = CityScript.BLOCKS
	var B: float = CityScript.BLOCK

	# lamps and stop signs at crossings
	for ix in range(1, n):
		for iz in range(1, n):
			var cx: float = city.road_center(ix)
			var cz: float = city.road_center(iz)
			var sx := 1.0 if _rng.randf() < 0.5 else -1.0
			var sz := 1.0 if _rng.randf() < 0.5 else -1.0
			_put("light-curved", Vector3(cx + sx * 5.3, SLAB_Y, cz + sz * 5.3), atan2(sx, sz), 1.0)
			if _rng.randf() < 0.15:
				_put("road-sign-stop", Vector3(cx - sx * 5.3, SLAB_Y, cz + sz * 5.3), atan2(-sx, sz), 1.0)

	# things along the footpath of every block
	for bx in n:
		for bz in n:
			var zone: int = city._zone_of_block(bx, bz)
			var ox: float = city.road_center(bx) + CityScript.ROAD * 0.5
			var oz: float = city.road_center(bz) + CityScript.ROAD * 0.5
			for edge in 4:
				var along_x := edge < 2
				var yaw_along := 0.0
				if not along_x:
					yaw_along = PI * 0.5
				for t in [6.0, 15.0, 24.0, 33.0]:
					if _rng.randf() < TREE_P[zone] * 0.5:
						var tree: String = TREES[_rng.randi() % TREES.size()]
						var sc := _rng.randf_range(0.8, 1.2)
						_put(tree, _edge_pos(ox, oz, B, edge, t), _rng.randf() * TAU, sc)
				var mid := _rng.randf_range(8.0, 28.0)
				if _rng.randf() < POLE_P[zone]:
					_put("electricity-pole", _edge_pos(ox, oz, B, edge, mid), yaw_along, 1.0)
				if _rng.randf() < BENCH_P[zone]:
					var flip := 0.0
					if _rng.randf() < 0.5:
						flip = PI
					_put("detail-bench", _edge_pos(ox, oz, B, edge, _rng.randf_range(8.0, 28.0)), yaw_along + flip, 1.0)
				if _rng.randf() < DUMP_P[zone]:
					_put("dumpster", _edge_pos(ox, oz, B, edge, _rng.randf_range(8.0, 28.0)), yaw_along, 1.0)
				if _rng.randf() < CONE_P[zone]:
					var base := _edge_pos(ox, oz, B, edge, _rng.randf_range(8.0, 28.0))
					for k in 3:
						var off := Vector3(0.0, 0.0, 0.0)
						if along_x:
							off.x = float(k) * 1.2
						else:
							off.z = float(k) * 1.2
						_put("construction-cone", base + off, 0.0, 1.0)
					_put("construction-barrier", base + Vector3(0.0, 0.0, 0.0) + (Vector3(4.0, 0.0, 0.0) if along_x else Vector3(0.0, 0.0, 4.0)), yaw_along, 1.0)

	_flush()


## A point on the footpath edge of a block (edge 0/1 = north/south side, 2/3 = west/east).
func _edge_pos(ox: float, oz: float, B: float, edge: int, t: float) -> Vector3:
	if edge == 0:
		return Vector3(ox + t, SLAB_Y, oz + 0.7)
	if edge == 1:
		return Vector3(ox + t, SLAB_Y, oz + B - 0.7)
	if edge == 2:
		return Vector3(ox + 0.7, SLAB_Y, oz + t)
	return Vector3(ox + B - 0.7, SLAB_Y, oz + t)


func _put(file: String, pos: Vector3, yaw: float, sc: float) -> void:
	var size: float = CHUNK * CityScript.PITCH
	var key := "%s|%d|%d" % [file, floori(pos.x / size), floori(pos.z / size)]
	var list: Array = _groups.get(key, [])
	list.append(Transform3D(Basis(Vector3.UP, yaw).scaled(Vector3(sc, sc, sc)), pos))
	_groups[key] = list


func _flush() -> void:
	for key in _groups:
		var file: String = String(key).split("|")[0]
		var m = _lib.mesh(DIR + file + ".glb")
		if m != null:
			_lib.add_multimesh(self, m, _groups[key], RANGE_END)
	_groups.clear()
