extends Node3D
## Traffic lights on every second crossing. Lights are shared by the whole grid
## (east-west green while north-south is red and the other way round). Poles are only
## drawn for the few crossings closest to you. Running a red light costs a fine.

signal fined(amount: int, reason: String)

const CityScript = preload("res://scripts/world/city.gd")

const CYCLE := 16.0
const STATIONS := 4
const SHOW_RANGE := 110.0
const POLE_FILE := "res://assets/models/props/traffic-light.glb"
# where the three lamps sit on the Kenney signal (green, yellow, red) at scale 9
const LAMP_X := -0.70
const LAMP_Y: Array[float] = [3.59, 3.97, 4.33]

var rickshaw = null
var t := 0.0

var _poles: Array = []            # each entry: [pole root Node3D, lamp MeshInstance3D, axis_x bool]
var _mats: Array[StandardMaterial3D] = []
var _model_ok := false
var _refresh_cd := 0.0
var _fine_cd := 0.0
var _was_inside := false


func setup(r) -> void:
	rickshaw = r
	for c in [Color(0.2, 0.95, 0.35), Color(1.0, 0.8, 0.1), Color(1.0, 0.2, 0.15)]:
		var m := StandardMaterial3D.new()
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.albedo_color = c
		m.disable_fog = true
		_mats.append(m)

	var pole_mesh: Mesh = null
	var ls = load("res://scripts/world/model_lib.gd")
	if ls != null and ls.can_instantiate():
		var lib = ls.new()
		pole_mesh = lib.mesh(POLE_FILE)
	_model_ok = pole_mesh != null

	var pole_mat := StandardMaterial3D.new()
	pole_mat.albedo_color = Color(0.25, 0.27, 0.30)
	for i in STATIONS * 4:
		var root := Node3D.new()
		var pole := MeshInstance3D.new()
		var lamp := MeshInstance3D.new()
		if _model_ok:
			pole.mesh = pole_mesh
			var ball := SphereMesh.new()
			ball.radius = 0.17
			ball.height = 0.34
			ball.radial_segments = 8
			ball.rings = 4
			lamp.mesh = ball
			lamp.position = Vector3(LAMP_X, LAMP_Y[2], 0.0)
		else:
			var pm := BoxMesh.new()
			pm.size = Vector3(0.25, 4.6, 0.25)
			pole.mesh = pm
			pole.position = Vector3(0.0, 2.3, 0.0)
			pole.material_override = pole_mat
			var lm := BoxMesh.new()
			lm.size = Vector3(0.7, 0.7, 0.7)
			lamp.mesh = lm
			lamp.position = Vector3(0.0, 4.9, 0.0)
		pole.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(pole)
		lamp.material_override = _mats[2]
		lamp.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(lamp)
		root.visible = false
		add_child(root)
		_poles.append([root, lamp, true])


func has_signal(ix: int, iz: int) -> bool:
	if ix <= 0 or iz <= 0 or ix >= CityScript.BLOCKS or iz >= CityScript.BLOCKS:
		return false
	return (ix + iz) % 2 == 0


## 0 = green, 1 = yellow, 2 = red for traffic moving along X (axis_x) or along Z.
func light_for(axis_x: bool) -> int:
	var p := fposmod(t, CYCLE)
	if axis_x:
		if p < 6.5:
			return 0
		if p < 8.0:
			return 1
		return 2
	if p < 8.0:
		return 2
	if p < 14.5:
		return 0
	return 1


func _grid_pos(ix: int, iz: int) -> Vector3:
	var half := float(CityScript.BLOCKS) * 0.5
	return Vector3((float(ix) - half) * CityScript.PITCH, 0.0, (float(iz) - half) * CityScript.PITCH)


func _grid_index(v: float) -> int:
	return clampi(roundi(v / CityScript.PITCH + float(CityScript.BLOCKS) * 0.5), 0, CityScript.BLOCKS)


func _physics_process(delta: float) -> void:
	t += delta
	_fine_cd = maxf(_fine_cd - delta, 0.0)
	if rickshaw == null:
		return
	var rp: Vector3 = rickshaw.global_position

	_refresh_cd -= delta
	if _refresh_cd <= 0.0:
		_refresh_cd = 0.4
		_place_poles(rp)

	for entry in _poles:
		var root: Node3D = entry[0]
		if root.visible:
			var lamp: MeshInstance3D = entry[1]
			var axis_x: bool = entry[2]
			var light := light_for(axis_x)
			lamp.material_override = _mats[light]
			if _model_ok:
				lamp.position.y = LAMP_Y[light]

	# Did the player drive into a crossing on red?
	var ix := _grid_index(rp.x)
	var iz := _grid_index(rp.z)
	var inside := false
	if has_signal(ix, iz):
		var c := _grid_pos(ix, iz)
		inside = absf(rp.x - c.x) < 4.2 and absf(rp.z - c.z) < 4.2
	if inside and not _was_inside and _fine_cd <= 0.0:
		var gt: Transform3D = rickshaw.global_transform
		var fwd := -gt.basis.z
		var along_x := absf(fwd.x) > absf(fwd.z)
		var speed: float = absf(rickshaw.forward_speed)
		if speed > 3.0 and light_for(along_x) == 2:
			_fine_cd = 8.0
			fined.emit(40, "Red light! Police fine Tk 40")
	_was_inside = inside


func _place_poles(rp: Vector3) -> void:
	var cx := _grid_index(rp.x)
	var cz := _grid_index(rp.z)
	var found: Array = []
	for dx in range(-3, 4):
		for dz in range(-3, 4):
			var ix := cx + dx
			var iz := cz + dz
			if ix < 0 or iz < 0 or ix > CityScript.BLOCKS or iz > CityScript.BLOCKS:
				continue
			if not has_signal(ix, iz):
				continue
			var c := _grid_pos(ix, iz)
			var d := Vector2(c.x - rp.x, c.z - rp.z).length()
			if d < SHOW_RANGE:
				found.append([d, ix, iz])
	found.sort_custom(func(a, b): return a[0] < b[0])

	# Four poles per crossing, each beside the road it controls. The lamps of the Kenney
	# model face -X, so every pole is turned until its lamps face the oncoming traffic.
	var corners: Array[Vector3] = [Vector3(-5.4, 0.0, -5.4), Vector3(5.4, 0.0, 5.4), Vector3(5.4, 0.0, -5.4), Vector3(-5.4, 0.0, 5.4)]
	var axes: Array[bool] = [true, true, false, false]
	var yaws: Array[float] = [0.0, PI, -PI * 0.5, PI * 0.5]
	var slot := 0
	for k in mini(found.size(), STATIONS):
		var ix: int = found[k][1]
		var iz: int = found[k][2]
		var c := _grid_pos(ix, iz)
		for j in 4:
			var entry: Array = _poles[slot]
			var root: Node3D = entry[0]
			root.position = c + corners[j]
			root.rotation.y = yaws[j]
			root.visible = true
			entry[2] = axes[j]
			slot += 1
	while slot < _poles.size():
		var spare: Node3D = _poles[slot][0]
		spare.visible = false
		slot += 1
