extends Node3D
## People walking along the footpaths, with real walking animations. They keep to the
## kerb and follow you around the city: anyone who falls too far behind reappears on a
## road near you.

const CityScript = preload("res://scripts/world/city.gd")

const COUNT := 22
const CURB := 4.85
const SLAB_Y := 0.25
const FAR := 170.0
const MODEL_SCALE := 2.3
const DIR := "res://assets/models/people/mini/"
const LOOKS: Array[String] = [
	"character-male-a", "character-male-b", "character-male-c", "character-male-d", "character-male-e", "character-male-f",
	"character-female-a", "character-female-b", "character-female-c", "character-female-d", "character-female-e", "character-female-f",
]

class Walker extends RefCounted:
	var holder: Node3D
	var horizontal := true     # walks along X when true, along Z when false
	var line := 0.0            # world coordinate of the road centre line
	var side := 1.0
	var along := 0.0
	var dir := 1.0
	var speed := 1.3

var rickshaw = null

var _walkers: Array = []
var _rng := RandomNumberGenerator.new()
var _lib = null


func setup(r) -> void:
	rickshaw = r
	_rng.randomize()
	var s = load("res://scripts/world/model_lib.gd")
	if s != null and s.can_instantiate():
		_lib = s.new()
	for i in COUNT:
		var w := Walker.new()
		w.holder = Node3D.new()
		add_child(w.holder)
		_fill_visual(w, i)
		_respawn(w, Vector3.ZERO)
		_walkers.append(w)


func _fill_visual(w: Walker, i: int) -> void:
	if _lib != null:
		var packed: PackedScene = _lib.scene(DIR + LOOKS[i % LOOKS.size()] + ".glb")
		if packed != null:
			var model: Node3D = packed.instantiate()
			model.rotation.y = PI             # the models face +Z, we walk towards -Z
			model.scale = Vector3.ONE * MODEL_SCALE
			w.holder.add_child(model)
			var ap: AnimationPlayer = _lib.find_player(model)
			_lib.play_loop(ap, "walk", _rng.randf_range(0.9, 1.15))
			return
	# simple stand-in when the model is missing
	var mi := MeshInstance3D.new()
	var capsule := CapsuleMesh.new()
	capsule.radius = 0.22
	capsule.height = 1.6
	mi.mesh = capsule
	mi.position = Vector3(0.0, 0.8, 0.0)
	w.holder.add_child(mi)


func _near_line(v: float) -> float:
	return float(clampi(roundi(v / CityScript.PITCH), -9, 9)) * CityScript.PITCH


func _respawn(w: Walker, around: Vector3) -> void:
	w.horizontal = _rng.randf() < 0.5
	if w.horizontal:
		w.line = _near_line(around.z + _rng.randf_range(-90.0, 90.0))
		w.along = clampf(around.x + _rng.randf_range(-110.0, 110.0), -400.0, 400.0)
	else:
		w.line = _near_line(around.x + _rng.randf_range(-90.0, 90.0))
		w.along = clampf(around.z + _rng.randf_range(-110.0, 110.0), -400.0, 400.0)
	w.side = 1.0 if _rng.randf() < 0.5 else -1.0
	w.dir = 1.0 if _rng.randf() < 0.5 else -1.0
	w.speed = _rng.randf_range(0.9, 1.5)


func _physics_process(delta: float) -> void:
	if rickshaw == null:
		return
	var rp: Vector3 = rickshaw.global_position
	for entry in _walkers:
		var w: Walker = entry
		w.along += w.dir * w.speed * delta
		if absf(w.along) > 400.0:
			w.dir = -w.dir
			w.along = clampf(w.along, -400.0, 400.0)

		var x := w.line + w.side * CURB
		var z: float = w.along
		var dx := 0.0
		var dz: float = w.dir
		if w.horizontal:
			x = w.along
			z = w.line + w.side * CURB
			dx = w.dir
			dz = 0.0

		if Vector2(x - rp.x, z - rp.z).length() > FAR:
			_respawn(w, rp)
			w.holder.reset_physics_interpolation()
			continue

		var cross := roundf(w.along / CityScript.PITCH) * CityScript.PITCH
		var y := SLAB_Y
		if absf(w.along - cross) < CityScript.ROAD * 0.5:
			y = 0.04
		w.holder.position = Vector3(x, y, z)
		w.holder.rotation.y = atan2(-dx, -dz)
