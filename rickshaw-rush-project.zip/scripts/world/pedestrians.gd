extends Node3D
## People walking along the footpaths. They keep to the kerb and follow you around the
## city: anyone who falls too far behind reappears on a road near you.

const CityScript = preload("res://scripts/world/city.gd")

const COUNT := 70
const CURB := 4.85
const SLAB_Y := 0.25
const FAR := 170.0

class Walker extends RefCounted:
	var horizontal := true     # walks along X when true, along Z when false
	var line := 0.0            # world coordinate of the road centre line
	var side := 1.0
	var along := 0.0
	var dir := 1.0
	var speed := 1.3
	var phase := 0.0

var rickshaw = null

var _walkers: Array = []
var _mm: MultiMesh
var _rng := RandomNumberGenerator.new()


func setup(r) -> void:
	rickshaw = r
	_rng.randomize()

	var capsule := CapsuleMesh.new()
	capsule.radius = 0.22
	capsule.height = 1.6
	capsule.radial_segments = 8
	capsule.rings = 3

	_mm = MultiMesh.new()
	_mm.transform_format = MultiMesh.TRANSFORM_3D
	_mm.use_colors = true
	_mm.mesh = capsule
	_mm.instance_count = COUNT

	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 1.0

	var inst := MultiMeshInstance3D.new()
	inst.multimesh = _mm
	inst.material_override = mat
	inst.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	inst.extra_cull_margin = 1000.0
	add_child(inst)

	for i in COUNT:
		var w := Walker.new()
		_respawn(w, Vector3.ZERO)
		_walkers.append(w)
		_mm.set_instance_color(i, Color.from_hsv(_rng.randf(), _rng.randf_range(0.35, 0.7), _rng.randf_range(0.55, 0.9)))


func _near_line(v: float) -> float:
	return float(clampi(roundi(v / CityScript.PITCH), -9, 9)) * CityScript.PITCH


func _respawn(w: Walker, around: Vector3) -> void:
	w.horizontal = _rng.randf() < 0.5
	if w.horizontal:
		w.line = _near_line(around.z + _rng.randf_range(-90.0, 90.0))
		w.along = clampf(around.x + _rng.randf_range(-110.0, 110.0), -400.0, 400.0)
	else:
		w.line = _near_line(around.x + _rng.randf_range(-90.0, 90.0))
		w.along = clampf(around.z + _rng.randf_range(-110.0, 110.0), -400.0, 400.0)
	w.side = 1.0 if _rng.randf() < 0.5 else -1.0
	w.dir = 1.0 if _rng.randf() < 0.5 else -1.0
	w.speed = _rng.randf_range(0.9, 1.6)
	w.phase = _rng.randf() * TAU


func _process(delta: float) -> void:
	if rickshaw == null:
		return
	var rp: Vector3 = rickshaw.global_position
	for i in COUNT:
		var w: Walker = _walkers[i]
		w.along += w.dir * w.speed * delta
		if absf(w.along) > 400.0:
			w.dir = -w.dir
			w.along = clampf(w.along, -400.0, 400.0)

		var x := w.line + w.side * CURB
		var z := w.along
		if w.horizontal:
			x = w.along
			z = w.line + w.side * CURB

		if Vector2(x - rp.x, z - rp.z).length() > FAR:
			_respawn(w, rp)
			continue

		var cross := roundf(w.along / CityScript.PITCH) * CityScript.PITCH
		var y := SLAB_Y
		if absf(w.along - cross) < CityScript.ROAD * 0.5:
			y = 0.04
		y += 0.8 + sin(w.phase + w.along * 3.0) * 0.03
		_mm.set_instance_transform(i, Transform3D(Basis.IDENTITY, Vector3(x, y, z)))
