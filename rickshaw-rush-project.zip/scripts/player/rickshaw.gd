extends CharacterBody3D
## Arcade rickshaw. The whole model is built from primitives in code (no external
## assets), and movement uses a light custom controller instead of heavy vehicle physics.
## Forward is -Z. Positive steer = right.

signal bell_rung
signal crashed(strength: float)

const MAX_SPEED := 11.0        # m/s, about 40 km/h arcade top speed
const ACCEL := 6.0
const COAST_DRAG := 2.4
const BRAKE_POWER := 10.0
const WHEEL_RADIUS := 0.35

# Inputs, written by the game script before each physics step.
var steer := 0.0               # -1 left .. +1 right
var pedaling := false
var braking := 0.0             # 0 .. 1

# State
var yaw := 0.0
var forward_speed := 0.0
var stamina := 1.0
var grip := 5.5                # lower = more sliding (wet roads later)

# Upgrade multipliers, set by the game script.
var speed_mult := 1.0
var accel_mult := 1.0
var drain_mult := 1.0
var road_grip_mult := 1.0     # below 1 on wet roads

var _vel := Vector3.ZERO
var _wheel_angle := 0.0
var _crank_angle := 0.0
var _steer_visual := 0.0
var _roll := 0.0
var _pitch := 0.0
var _bob_t := 0.0
var _bell_cooldown := 0.0

var _model: Node3D
var _fork: Node3D
var _wheels: Array[Node3D] = []
var _legs: Array[Node3D] = []
var _bell_player: AudioStreamPlayer
var _hood_mat: StandardMaterial3D
var _passenger: Node3D
var _passenger_mat: StandardMaterial3D
var _pedal_player: AudioStreamPlayer
var _crash_player: AudioStreamPlayer
var _crash_cd := 0.0
var _crash_heavy: Array = []
var _crash_light: Array = []


func _ready() -> void:
	motion_mode = CharacterBody3D.MOTION_MODE_FLOATING
	axis_lock_linear_y = true

	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(1.4, 1.5, 2.5)
	shape.shape = box
	shape.position = Vector3(0.0, 0.85, -0.3)
	add_child(shape)

	_model = Node3D.new()
	add_child(_model)
	_build_model()
	_build_passenger()
	_build_shadow()
	_setup_audio()
	_setup_sfx()


func reset_to(pos: Vector3, new_yaw: float) -> void:
	position = pos
	yaw = new_yaw
	rotation = Vector3(0.0, yaw, 0.0)
	forward_speed = 0.0
	stamina = 1.0
	_vel = Vector3.ZERO
	velocity = Vector3.ZERO
	reset_physics_interpolation()


func ring_bell() -> void:
	if _bell_cooldown > 0.0:
		return
	_bell_cooldown = 0.35
	bell_rung.emit()
	if _bell_player != null and _bell_player.stream != null:
		_bell_player.play()


func _physics_process(delta: float) -> void:
	var speed_ratio := clampf(absf(forward_speed) / MAX_SPEED, 0.0, 1.0)

	# Stamina: pedalling drains it, resting refills it. Low stamina lowers top speed.
	if pedaling:
		stamina -= (0.05 + 0.10 * speed_ratio) * drain_mult * delta
	else:
		stamina += 0.14 * delta
	stamina = clampf(stamina, 0.0, 1.0)
	var top_speed := MAX_SPEED * speed_mult * lerpf(0.5, 1.0, clampf(stamina / 0.25, 0.0, 1.0))

	# Forward speed
	if pedaling:
		if forward_speed < top_speed:
			forward_speed = minf(forward_speed + ACCEL * accel_mult * (1.0 - speed_ratio * 0.6) * delta, top_speed)
		else:
			forward_speed = move_toward(forward_speed, top_speed, COAST_DRAG * delta)
	else:
		forward_speed = move_toward(forward_speed, 0.0, (COAST_DRAG + speed_ratio * speed_ratio * 2.5) * delta)
	if braking > 0.0:
		forward_speed = move_toward(forward_speed, 0.0, BRAKE_POWER * braking * delta)

	# Heading: a rickshaw cannot spin on the spot, so steering needs some speed.
	var authority := clampf(absf(forward_speed) / 2.5, 0.0, 1.0)
	var turn_rate := lerpf(1.9, 0.95, speed_ratio)
	yaw -= steer * turn_rate * authority * delta
	rotation.y = yaw

	# Velocity: forward part is controlled directly, sideways part slowly dies out.
	# That leftover sideways motion is what gives the slide in fast turns.
	var fwd := Vector3(-sin(yaw), 0.0, -cos(yaw))
	var lateral := _vel - fwd * _vel.dot(fwd)
	lateral *= exp(-grip * road_grip_mult * delta)
	_vel = fwd * forward_speed + lateral
	_vel.y = 0.0
	var speed_before := absf(forward_speed)
	velocity = _vel
	move_and_slide()
	_vel = velocity
	_vel.y = 0.0
	forward_speed = _vel.dot(fwd)

	# Bumping into something hard: report it and play a thud.
	_crash_cd = maxf(_crash_cd - delta, 0.0)
	if get_slide_collision_count() > 0 and _crash_cd <= 0.0:
		var lost := speed_before - absf(forward_speed)
		if lost > 2.5:
			_crash_cd = 0.8
			crashed.emit(lost)
			var pool: Array = _crash_light
			if lost > 5.0:
				pool = _crash_heavy
			if _crash_player != null:
				if not pool.is_empty():
					_crash_player.stream = pool[randi() % pool.size()]
				if _crash_player.stream != null:
					_crash_player.volume_db = lerpf(-12.0, -1.0, clampf(lost / 8.0, 0.0, 1.0))
					_crash_player.play()

	_update_sfx(speed_ratio)
	_animate(delta, speed_ratio)


func _animate(delta: float, speed_ratio: float) -> void:
	_bell_cooldown = maxf(_bell_cooldown - delta, 0.0)

	_wheel_angle = fmod(_wheel_angle + forward_speed / WHEEL_RADIUS * delta, TAU)
	for w in _wheels:
		w.rotation.x = -_wheel_angle

	var crank_rate := forward_speed if pedaling else forward_speed * 0.15
	_crank_angle = fmod(_crank_angle + crank_rate * 1.1 * delta, TAU)
	for i in _legs.size():
		_legs[i].rotation.x = sin(_crank_angle + float(i) * PI) * 0.55

	var k := 1.0 - exp(-8.0 * delta)
	_steer_visual = lerpf(_steer_visual, steer * 0.5, 1.0 - exp(-10.0 * delta))
	_fork.rotation.y = -_steer_visual

	var target_roll := steer * speed_ratio * 0.13
	var target_pitch := -0.07 * braking
	if pedaling:
		target_pitch += 0.03 * (1.0 - speed_ratio)
	_roll = lerpf(_roll, target_roll, k)
	_pitch = lerpf(_pitch, target_pitch, k)
	_bob_t += delta * (6.0 + forward_speed * 1.4)
	_model.rotation = Vector3(_pitch, 0.0, _roll + sin(_bob_t * 0.5) * 0.012 * speed_ratio)
	_model.position.y = absf(sin(_bob_t)) * 0.02 * speed_ratio


# ---------------------------------------------------------------- model building

func _build_model() -> void:
	var steel := _mat(Color(0.10, 0.10, 0.12))
	var chrome := _mat(Color(0.78, 0.80, 0.84), 0.4)
	var tire := _mat(Color(0.05, 0.05, 0.06))
	var teal := _mat(Color(0.05, 0.50, 0.55))
	var red := _mat(Color(0.78, 0.10, 0.12))
	_hood_mat = red
	var gold := _mat(Color(0.98, 0.78, 0.14))
	var seat_mat := _mat(Color(0.55, 0.12, 0.14))
	var skin := _mat(Color(0.55, 0.38, 0.28))
	var shirt := _mat(Color(0.20, 0.55, 0.78))
	var lungi := _mat(Color(0.18, 0.28, 0.55))
	var shoe := _mat(Color(0.12, 0.12, 0.12))
	var cap := _mat(Color(0.95, 0.95, 0.92))

	# Frame
	_box(_model, Vector3(0.05, 0.05, 0.75), Vector3(0.0, 0.98, -0.72), steel)
	_box(_model, Vector3(0.05, 0.05, 0.78), Vector3(0.0, 0.725, -0.825), steel, Vector3(PI * 0.25, 0.0, 0.0))
	_box(_model, Vector3(0.05, 0.54, 0.05), Vector3(0.0, 0.70, -0.45), steel, Vector3(0.38, 0.0, 0.0))
	_box(_model, Vector3(0.05, 0.05, 1.10), Vector3(0.0, 0.42, 0.0), steel, Vector3(0.09, 0.0, 0.0))
	_box(_model, Vector3(1.30, 0.04, 0.04), Vector3(0.0, 0.35, 0.55), steel)

	# Passenger platform, side panels, seat
	_box(_model, Vector3(1.0, 0.06, 0.95), Vector3(0.0, 0.50, 0.50), teal)
	_box(_model, Vector3(0.05, 0.32, 0.95), Vector3(-0.52, 0.64, 0.50), teal)
	_box(_model, Vector3(0.05, 0.32, 0.95), Vector3(0.52, 0.64, 0.50), teal)
	_box(_model, Vector3(0.90, 0.14, 0.55), Vector3(0.0, 0.60, 0.42), seat_mat)
	_box(_model, Vector3(0.90, 0.50, 0.10), Vector3(0.0, 0.90, 0.72), seat_mat, Vector3(0.18, 0.0, 0.0))

	# Painted back panel: the rickshaw art the camera looks at all game long
	_box(_model, Vector3(1.20, 0.86, 0.05), Vector3(0.0, 0.93, 0.97), gold)
	var art := MeshInstance3D.new()
	var quad := QuadMesh.new()
	quad.size = Vector2(1.08, 0.74)
	art.mesh = quad
	var art_mat := StandardMaterial3D.new()
	art_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	art_mat.albedo_texture = _make_art_texture()
	art.material_override = art_mat
	art.position = Vector3(0.0, 0.93, 1.0)
	art.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_model.add_child(art)

	# Hood
	_box(_model, Vector3(1.32, 0.05, 1.30), Vector3(0.0, 1.60, 0.38), red, Vector3(0.05, 0.0, 0.0))
	_box(_model, Vector3(1.38, 0.03, 1.36), Vector3(0.0, 1.575, 0.38), gold, Vector3(0.05, 0.0, 0.0))
	for sx in [-0.62, 0.62]:
		_box(_model, Vector3(0.03, 1.05, 0.03), Vector3(sx, 1.05, 0.92), steel)
		_box(_model, Vector3(0.03, 1.05, 0.03), Vector3(sx, 1.05, -0.10), steel)

	# Rear wheels
	_make_wheel(_model, Vector3(-0.62, WHEEL_RADIUS, 0.55), tire, chrome, gold)
	_make_wheel(_model, Vector3(0.62, WHEEL_RADIUS, 0.55), tire, chrome, gold)

	# Steering fork with front wheel and handlebar
	_fork = Node3D.new()
	_fork.position = Vector3(0.0, 0.0, -1.15)
	_model.add_child(_fork)
	_make_wheel(_fork, Vector3(0.0, WHEEL_RADIUS, 0.0), tire, chrome, gold)
	for sx in [-0.08, 0.08]:
		_box(_fork, Vector3(0.035, 0.70, 0.035), Vector3(sx, 0.68, 0.0), steel)
	_box(_fork, Vector3(0.04, 0.14, 0.04), Vector3(0.0, 1.00, 0.10), steel)
	_box(_fork, Vector3(0.72, 0.035, 0.035), Vector3(0.0, 1.07, 0.12), chrome)
	_sphere(_fork, 0.045, Vector3(0.22, 1.12, 0.12), chrome)

	# Driver
	_box(_model, Vector3(0.22, 0.06, 0.32), Vector3(0.0, 0.96, -0.36), steel)
	for i in 2:
		var sx := -0.11 if i == 0 else 0.11
		var hip := Node3D.new()
		hip.position = Vector3(sx, 0.95, -0.38)
		_model.add_child(hip)
		_box(hip, Vector3(0.10, 0.58, 0.10), Vector3(0.0, -0.29, 0.0), lungi)
		_box(hip, Vector3(0.10, 0.05, 0.22), Vector3(0.0, -0.60, -0.06), shoe)
		_legs.append(hip)
	_capsule(_model, 0.17, 0.72, Vector3(0.0, 1.40, -0.42), shirt, Vector3(-0.3, 0.0, 0.0))
	_sphere(_model, 0.14, Vector3(0.0, 1.86, -0.55), skin)
	_cyl(_model, 0.14, 0.07, Vector3(0.0, 1.98, -0.55), cap)
	for sx in [-0.25, 0.25]:
		_box(_model, Vector3(0.07, 0.79, 0.07), Vector3(sx, 1.36, -0.765), shirt, Vector3(0.74, 0.0, 0.0))


func _setup_sfx() -> void:
	_pedal_player = AudioStreamPlayer.new()
	_pedal_player.volume_db = -16.0
	add_child(_pedal_player)
	var path := "res://assets/audio/pedal_loop.wav"
	if ResourceLoader.exists(path):
		var stream = load(path)
		if stream is AudioStreamWAV:
			stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
			stream.loop_begin = 0
			stream.loop_end = int(stream.data.size() / 2)
		_pedal_player.stream = stream
	_crash_player = AudioStreamPlayer.new()
	add_child(_crash_player)
	if ResourceLoader.exists("res://assets/audio/crash.wav"):
		_crash_player.stream = load("res://assets/audio/crash.wav")
	var dir := "res://assets/audio/kenney/"
	for n in ["impactMetal_heavy_000", "impactMetal_heavy_001", "impactMetal_heavy_002", "impactPlate_heavy_000"]:
		if ResourceLoader.exists(dir + n + ".ogg"):
			_crash_heavy.append(load(dir + n + ".ogg"))
	for n in ["impactMetal_light_000", "impactMetal_light_001", "impactMetal_light_002", "impactGeneric_light_000", "impactGeneric_light_001"]:
		if ResourceLoader.exists(dir + n + ".ogg"):
			_crash_light.append(load(dir + n + ".ogg"))


func _update_sfx(speed_ratio: float) -> void:
	if _pedal_player == null or _pedal_player.stream == null:
		return
	if pedaling and absf(forward_speed) > 0.6:
		_pedal_player.pitch_scale = 0.8 + speed_ratio * 0.9
		if not _pedal_player.playing:
			_pedal_player.play()
	elif _pedal_player.playing:
		_pedal_player.stop()


func _build_passenger() -> void:
	_passenger = Node3D.new()
	_model.add_child(_passenger)
	_passenger_mat = _mat(Color(0.9, 0.5, 0.2))
	var skin := _mat(Color(0.60, 0.42, 0.30))
	_capsule(_passenger, 0.2, 0.62, Vector3(0.0, 1.02, 0.50), _passenger_mat)
	_sphere(_passenger, 0.13, Vector3(0.0, 1.42, 0.50), skin)
	_passenger.visible = false


func set_passenger(on: bool, color: Color = Color.WHITE) -> void:
	_passenger_mat.albedo_color = color
	_passenger.visible = on


func set_hood_color(c: Color) -> void:
	if _hood_mat != null:
		_hood_mat.albedo_color = c


func _build_shadow() -> void:
	var mi := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 1.0
	cyl.bottom_radius = 1.0
	cyl.height = 0.01
	cyl.radial_segments = 16
	cyl.rings = 1
	mi.mesh = cyl
	mi.scale = Vector3(0.75, 1.0, 1.5)
	mi.position = Vector3(0.0, 0.06, -0.15)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = Color(0.0, 0.0, 0.0, 0.35)
	mi.material_override = m
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)


func _setup_audio() -> void:
	_bell_player = AudioStreamPlayer.new()
	_bell_player.volume_db = -4.0
	add_child(_bell_player)
	if ResourceLoader.exists("res://assets/audio/bell.wav"):
		_bell_player.stream = load("res://assets/audio/bell.wav")


func _make_wheel(parent: Node3D, pos: Vector3, tire_mat: Material, spoke_mat: Material, hub_mat: Material) -> void:
	var wheel := Node3D.new()
	wheel.position = pos
	parent.add_child(wheel)
	var tire := MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 0.29
	torus.outer_radius = 0.37
	torus.rings = 16
	torus.ring_segments = 6
	tire.mesh = torus
	tire.material_override = tire_mat
	tire.rotation = Vector3(0.0, 0.0, PI * 0.5)
	tire.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	wheel.add_child(tire)
	_box(wheel, Vector3(0.025, 0.62, 0.02), Vector3.ZERO, spoke_mat)
	_box(wheel, Vector3(0.025, 0.62, 0.02), Vector3.ZERO, spoke_mat, Vector3(PI * 0.5, 0.0, 0.0))
	_cyl(wheel, 0.06, 0.12, Vector3.ZERO, hub_mat, Vector3(0.0, 0.0, PI * 0.5))
	_wheels.append(wheel)


func _make_art_texture() -> ImageTexture:
	const W := 160
	const H := 112
	var img := Image.create(W, H, false, Image.FORMAT_RGBA8)
	var sky_top := Color(0.08, 0.52, 0.66)
	var sky_low := Color(0.99, 0.86, 0.55)
	var hill := Color(0.10, 0.50, 0.24)
	var water_a := Color(0.12, 0.34, 0.72)
	var water_b := Color(0.20, 0.50, 0.85)
	for y in H:
		for x in W:
			var c := sky_top.lerp(sky_low, clampf(float(y) / (float(H) * 0.62), 0.0, 1.0))
			var d := Vector2(x, y).distance_to(Vector2(80.0, 54.0))
			if d < 20.0:
				c = Color(0.96, 0.28, 0.16)
			elif d < 24.0:
				c = Color(1.0, 0.78, 0.20)
			var hill_line := 70.0 - 9.0 * sin(x * 0.07 + 1.0) - 5.0 * sin(x * 0.19)
			if y > hill_line:
				c = hill
			if y > 86:
				c = water_a if (floori((y - 86) / 4.0) + floori(x / 10.0)) % 2 == 0 else water_b
			# little sailing boat
			if x >= 104 and x <= 134 and y >= 84 and y <= 88:
				c = Color(0.45, 0.25, 0.12)
			if x >= 110 and x <= 128 and y >= 58 and y < 84:
				if float(x - 110) <= float(y - 58) * (18.0 / 26.0):
					c = Color(0.97, 0.97, 0.93)
			# checkered border
			var edge := mini(mini(x, W - 1 - x), mini(y, H - 1 - y))
			if edge < 7:
				if (floori(x / 8.0) + floori(y / 8.0)) % 2 == 0:
					c = Color(0.85, 0.10, 0.35)
				else:
					c = Color(1.0, 0.82, 0.15)
			img.set_pixel(x, y, c)
	return ImageTexture.create_from_image(img)


# ---------------------------------------------------------------- small helpers

func _mat(color: Color, rough: float = 0.85) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	return m


func _box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	return _place(parent, mesh, pos, mat, rot)


func _cyl(parent: Node3D, radius: float, height: float, pos: Vector3, mat: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 12
	mesh.rings = 1
	return _place(parent, mesh, pos, mat, rot)


func _sphere(parent: Node3D, radius: float, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	mesh.radial_segments = 12
	mesh.rings = 6
	return _place(parent, mesh, pos, mat, Vector3.ZERO)


func _capsule(parent: Node3D, radius: float, height: float, pos: Vector3, mat: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mesh := CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = height
	mesh.radial_segments = 12
	mesh.rings = 4
	return _place(parent, mesh, pos, mat, rot)


func _place(parent: Node3D, mesh: Mesh, pos: Vector3, mat: Material, rot: Vector3) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi
