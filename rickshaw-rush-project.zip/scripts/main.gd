extends Node3D
## Rickshaw Rush: world setup, input, menus and the game systems.
## Desktop test keys: A/D or arrows = steer, W/Up/Space = pedal, S/Down = brake, B = bell, R = reset, Esc = pause.

const RickshawScript = preload("res://scripts/player/rickshaw.gd")
const ChaseCameraScript = preload("res://scripts/player/chase_camera.gd")
const CityScript = preload("res://scripts/world/city.gd")
const TouchControlsScript = preload("res://scripts/ui/touch_controls.gd")
const HudScript = preload("res://scripts/ui/hud.gd")
const UiTheme = preload("res://scripts/ui/ui_theme.gd")
const GameStateScript = preload("res://scripts/game/game_state.gd")
const TripScript = preload("res://scripts/game/trip_manager.gd")
const TripHudScript = preload("res://scripts/ui/trip_hud.gd")
const GarageScript = preload("res://scripts/ui/garage_panel.gd")
const MenuScript = preload("res://scripts/ui/menu_panel.gd")

const SPAWN := Vector3(0.0, 0.04, 0.0)
const SUBDIVS: Array[int] = [2, 3, 4]       # plots per block side: 4, 9, 16 buildings per block
const FOG_COLOR := Color(0.80, 0.74, 0.62)

var quality := 1
var stress := 0

var env: Environment
var sun: DirectionalLight3D
var city
var rickshaw
var cam
var touch
var hud
var state
var trips
var trip_hud
var garage
var menu
var weather
var traffic
var peds
var lights
var sfx
var progress
var props
var pickups


func _ready() -> void:
	DisplayServer.screen_set_keep_on(true)
	_setup_environment()

	state = GameStateScript.new()
	state.load_game()

	city = CityScript.new()
	add_child(city)
	city.build(SUBDIVS[stress])

	rickshaw = RickshawScript.new()
	add_child(rickshaw)
	rickshaw.reset_to(SPAWN, 0.0)
	_apply_upgrades()

	cam = ChaseCameraScript.new()
	add_child(cam)
	cam.target = rickshaw
	cam.current = true

	weather = _try_system("res://scripts/world/weather.gd")
	if weather != null:
		weather.setup(env, sun, rickshaw, cam)
	sfx = _try_system("res://scripts/game/sfx.gd")
	if sfx != null:
		sfx.setup()
	lights = _try_system("res://scripts/world/traffic_signals.gd")
	if lights != null:
		lights.setup(rickshaw)
		lights.fined.connect(_on_fined)
	traffic = _try_system("res://scripts/world/traffic.gd")
	if traffic != null:
		traffic.setup(rickshaw)
		traffic.lights = lights
		traffic.weather = weather
		traffic.fined.connect(_on_fined)
	peds = _try_system("res://scripts/world/pedestrians.gd")
	if peds != null:
		peds.setup(rickshaw)
	props = _try_system("res://scripts/world/city_props.gd")
	if props != null:
		props.setup(city)
	pickups = _try_system("res://scripts/world/pickups.gd")
	if pickups != null:
		pickups.setup(rickshaw)

	trips = TripScript.new()
	add_child(trips)
	trips.setup(rickshaw, city, state)
	trips.trip_finished.connect(_on_trip_finished)

	progress = _try_system("res://scripts/game/progress.gd")
	if progress != null:
		progress.setup(state, trips, rickshaw, weather, city)
		progress.sfx.connect(_play_sfx)

	_build_ui()
	_apply_settings()
	_refresh_info()
	if progress != null:
		progress.announce()
	trips.start()

	# Start on the title screen with the world frozen behind it.
	touch.release_all()
	menu.open_title()
	get_tree().paused = true


func _setup_environment() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = FOG_COLOR
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.85, 0.82, 0.78)
	env.ambient_light_energy = 0.65
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = FOG_COLOR
	env.fog_density = 0.015

	var world_env := WorldEnvironment.new()
	world_env.environment = env
	add_child(world_env)

	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52.0, -35.0, 0.0)
	sun.light_color = Color(1.0, 0.92, 0.78)
	sun.light_energy = 1.1
	sun.shadow_enabled = false
	add_child(sun)


func _build_ui() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 10
	add_child(layer)

	var root := Control.new()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = UiTheme.make()
	layer.add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	hud = HudScript.new()
	root.add_child(hud)
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.rickshaw = rickshaw

	touch = TouchControlsScript.new()
	root.add_child(touch)
	touch.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	touch.bell_pressed.connect(rickshaw.ring_bell)

	trip_hud = TripHudScript.new()
	root.add_child(trip_hud)
	trip_hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	trip_hud.rickshaw = rickshaw
	trip_hud.trips = trips
	trip_hud.state = state
	trips.message.connect(trip_hud.show_toast)
	trip_hud.city = city
	if pickups != null:
		pickups.collected.connect(trip_hud.show_toast)
		pickups.collected.connect(_on_pickup)
	if progress != null:
		trip_hud.progress = progress
		progress.message.connect(trip_hud.show_toast)
	if traffic != null:
		traffic.notice.connect(trip_hud.show_toast)
	if weather != null:
		trip_hud.weather = weather
		weather.message.connect(trip_hud.show_toast)

	var box := VBoxContainer.new()
	box.anchor_left = 1.0
	box.anchor_right = 1.0
	box.anchor_top = 0.0
	box.anchor_bottom = 0.0
	box.offset_left = -220.0
	box.offset_right = -20.0
	box.offset_top = 20.0
	box.add_theme_constant_override("separation", 10)
	root.add_child(box)

	box.add_child(_make_button("Pause", _on_pause_pressed))
	box.add_child(_make_button("Garage", _on_garage_pressed))
	box.add_child(_make_button("Reset position", _on_reset_pressed))

	garage = GarageScript.new()
	root.add_child(garage)
	garage.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	garage.setup(state)
	garage.changed.connect(_apply_upgrades)
	garage.closed.connect(_on_garage_closed)

	menu = MenuScript.new()
	root.add_child(menu)
	menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu.setup(state)
	menu.progress = progress
	menu.daily_claimed.connect(_on_daily_claimed)
	menu.play_pressed.connect(_on_menu_closed)
	menu.resume_pressed.connect(_on_menu_closed)
	menu.garage_pressed.connect(_on_garage_pressed)
	menu.settings_changed.connect(_apply_settings)
	menu.reset_requested.connect(_apply_upgrades)


func _make_button(label: String, callback: Callable) -> Button:
	var b := Button.new()
	b.text = label
	b.custom_minimum_size = Vector2(200.0, 52.0)
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(callback)
	b.pressed.connect(func(): _play_sfx("click"))
	return b


func _physics_process(_delta: float) -> void:
	# Touch first, keyboard overrides for desktop testing.
	var steer: float = touch.steer
	var pedal: bool = touch.pedal_down
	var brake: float = touch.brake

	var k := 0.0
	if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT):
		k -= 1.0
	if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT):
		k += 1.0
	if absf(k) > 0.0:
		steer = k
	if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP) or Input.is_physical_key_pressed(KEY_SPACE):
		pedal = true
	if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN):
		brake = 1.0

	rickshaw.steer = steer
	rickshaw.pedaling = pedal
	rickshaw.braking = brake


func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.physical_keycode == KEY_B:
			rickshaw.ring_bell()
		elif event.physical_keycode == KEY_R:
			_on_reset_pressed()
		elif event.physical_keycode == KEY_ESCAPE:
			_on_pause_pressed()


func _on_reset_pressed() -> void:
	rickshaw.reset_to(SPAWN, 0.0)
	cam.snap()


func _on_pause_pressed() -> void:
	state.save_game()
	touch.release_all()
	menu.open_pause()
	get_tree().paused = true


func _on_menu_closed() -> void:
	get_tree().paused = false


func _apply_settings() -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(float(state.volume), 0.0001)))
	AudioServer.set_bus_mute(0, float(state.volume) <= 0.001)
	quality = clampi(int(state.quality), 0, 2)
	hud.show_stats = bool(state.show_stats)
	if sfx != null:
		sfx.set_music(bool(state.music_on))
	_apply_quality()


func _apply_quality() -> void:
	var scales: Array[float] = [0.65, 0.85, 1.0]
	var fars: Array[float] = [130.0, 190.0, 260.0]
	var fogs: Array[float] = [0.022, 0.015, 0.011]
	var vp := get_viewport()
	vp.scaling_3d_scale = scales[quality]
	vp.msaa_3d = Viewport.MSAA_2X if quality == 2 else Viewport.MSAA_DISABLED
	cam.far = fars[quality]
	env.fog_density = fogs[quality]
	if weather != null:
		weather.fog_base = fogs[quality]


func _refresh_info() -> void:
	hud.info_text = "Buildings  %d" % city.building_count


func _apply_upgrades() -> void:
	var tires: int = state.levels[0]
	var chain: int = state.levels[1]
	var legs: int = state.levels[2]
	rickshaw.grip = 5.5 + 1.0 * float(tires)
	rickshaw.speed_mult = 1.0 + 0.04 * float(tires) + 0.03 * float(chain)
	rickshaw.accel_mult = 1.0 + 0.2 * float(chain)
	rickshaw.drain_mult = 1.0 - 0.2 * float(legs)
	rickshaw.set_hood_color(state.paint_color())


func _on_garage_pressed() -> void:
	touch.release_all()
	garage.open()
	get_tree().paused = true


func _on_garage_closed() -> void:
	get_tree().paused = false


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_on_back_request()
	# 2015 = the app is sent to the background on Android
	elif what == 2015 or what == NOTIFICATION_WM_CLOSE_REQUEST:
		if state != null:
			state.save_game()
		if what == 2015 and menu != null and not menu.visible and not garage.visible:
			_on_pause_pressed()


func _on_back_request() -> void:
	if menu == null or garage == null:
		return
	if menu.visible:
		menu.back()
	elif garage.visible:
		garage.close()
	else:
		_on_pause_pressed()


## Loads an optional game system. If its script has an error the game still starts without it.
func _try_system(path: String) -> Node:
	var script = load(path)
	if script == null or not script.can_instantiate():
		push_warning("Could not load " + path)
		return null
	var node = script.new()
	add_child(node)
	return node


func _play_sfx(sound: String) -> void:
	if sfx != null:
		sfx.play(sound)


func _on_fined(amount: int, reason: String) -> void:
	state.money = maxi(int(state.money) - amount, 0)
	state.save_game()
	trip_hud.show_toast(reason)
	_play_sfx("whistle")


func _on_trip_finished(_info: Dictionary) -> void:
	_play_sfx("coin")


func _on_daily_claimed(amount: int) -> void:
	_play_sfx("coin")
	trip_hud.show_toast("Daily reward: Tk %d|Come back tomorrow for more!" % amount)


func _on_pickup(_text: String) -> void:
	_play_sfx("click")
