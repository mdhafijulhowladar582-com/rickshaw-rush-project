# Rickshaw Rush

3D Dhaka rickshaw driving and career game, built with Godot 4.4 (GL Compatibility renderer).

## Status: phase 6 (3D models)

- Android build pipeline (GitHub Actions)
- Performance test city (adjustable density and graphics quality, FPS / draw calls / triangles on screen)
- Drivable rickshaw: arcade handling, stamina, skid, chase camera, touch controls
- Passenger jobs: pick up at the yellow marker, drop off at the green marker, fare + tip (or late penalty)
- Cash, Garage with 4 upgrades (tires, chain, legs, seat) and hood repaint, progress saved on the phone
- Solid buildings and city edge walls
- Living city: moving cars, buses and rickshaws that brake and honk, people on the footpaths
- Four areas (Old Dhaka, Motijheel, Dhanmondi, Sadarghat) with their own look, a river at the edge
- Day and night (6 minute day), headlight, random rain with slippery roads, city and rain sound
- Title screen, pause menu (also Esc / Android back / app switch), settings (volume, graphics, FPS stats, reset progress), first-run how-to-play
- Custom launcher icon (adaptive), loading splash screen
- Story: 10 missions following Rahim, 10 achievements, daily reward with streak
- Traffic lights, police cars (speeding fines), red-light fines, rush-hour traffic jams
- Real 3D models: cars, trucks and police cars in traffic, animated walking people, houses in Dhanmondi, street lamps, poles, trees, benches, cones, dumpsters
- Street food pickups that refill stamina
- Pedal/chain sound, crash sounds, coin/achievement/UI sounds, background music loop

## Controls

Touch (landscape): left side = floating steering stick (pull down to brake), PEDAL = hold to pedal, BELL = tap.
Slow down inside the marker circle to pick up or drop off. GARAGE button (top right) opens the upgrade shop.

Desktop: A/D or arrows steer, W/Up/Space pedal, S/Down brake, B bell, R reset.

## Get the APK from GitHub

1. Put `.github/workflows/build-apk.yml` in the repo.
2. Upload either the project files as they are, or only `rickshaw-rush-project.zip`, to the repo root.
3. Open the Actions tab, run "Build Android APK" (it also runs on every push).
4. Download the `RickshawRush-debug-apk` artifact from the finished run, unzip it, install the APK.

`debug.keystore` is included so every new build installs over the previous one.

## Layout

    scenes/main.tscn            single entry scene
    scripts/main.gd             world setup, input, perf test buttons, garage hookup
    scripts/game/               save data + upgrades, trips, missions/achievements, sound
    scripts/player/             rickshaw model + controller, chase camera
    scripts/world/city.gd       procedural city (MultiMesh based), areas, collision
    scripts/world/traffic.gd    moving vehicles, police, rush hour
    scripts/world/traffic_signals.gd  traffic lights and red-light fines
    scripts/world/pedestrians.gd animated walking people
    scripts/world/city_props.gd street furniture, city_houses.gd houses, pickups.gd food, model_lib.gd model loader
    assets/models/              baked Kenney models (see licenses/)
    scripts/world/weather.gd    day/night, rain, ambient sound
    scripts/ui/                 theme, touch controls, HUD, trip HUD, garage panel, menu panel
    assets/audio/bell.wav       generated bell sound

## Credits

- 3D models by Kenney (www.kenney.nl), CC0: Car Kit, City Kit (Roads), City Kit (Suburban), Retro Urban Kit,
  Mini Characters, Blocky Characters, Food Kit. Licences in `assets/models/licenses/`.
- Interface Sounds, Impact Sounds and Digital Audio by Kenney, CC0. Used files are in `assets/audio/kenney/`.
- Pedal, crash fallback, horns, rain, ambience, whistle and music loop are generated for this project.
