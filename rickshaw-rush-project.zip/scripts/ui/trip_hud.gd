extends Control
## Cash, job status, direction arrow and short messages.

const TripScript = preload("res://scripts/game/trip_manager.gd")
const UiTheme = preload("res://scripts/ui/ui_theme.gd")

var rickshaw = null
var trips = null
var state = null

var _card: StyleBoxFlat
var _toast := ""
var _toast_t := 0.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_card = UiTheme.panel_box()


func show_toast(text: String) -> void:
	_toast = text
	_toast_t = 4.0


func _process(delta: float) -> void:
	_toast_t = maxf(_toast_t - delta, 0.0)
	queue_redraw()


func _draw() -> void:
	if rickshaw == null or trips == null or state == null:
		return
	var font := ThemeDB.fallback_font
	var ph: int = trips.phase

	draw_style_box(_card, Rect2(330.0, 20.0, 300.0, 112.0))
	draw_string(font, Vector2(346.0, 56.0), "Cash  Tk %d" % int(state.money), HORIZONTAL_ALIGNMENT_LEFT, -1, 28, Color(1.0, 0.85, 0.3))

	var line := "Looking for a passenger..."
	var sub := ""
	if ph == TripScript.PH_WAIT:
		line = "Pick up: %s" % trips.passenger_name()
		sub = "Yellow marker, %d m away" % int(trips.distance)
	elif ph == TripScript.PH_TRIP:
		line = "Drop off - fare Tk %d" % int(trips.base_fare)
		sub = "Green marker, %d m away" % int(trips.distance)
	draw_string(font, Vector2(346.0, 82.0), line, HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color.WHITE)
	draw_string(font, Vector2(346.0, 102.0), sub, HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color(1.0, 1.0, 1.0, 0.75))

	if ph == TripScript.PH_TRIP:
		var left: float = trips.time_left
		var total: float = trips.time_allowed
		var frac := clampf(left / total, 0.0, 1.0)
		var col := Color(0.4, 0.9, 0.45)
		if frac < 0.3:
			col = Color(1.0, 0.45, 0.3)
		var txt := "LATE"
		if left >= 0.0:
			txt = "%d s" % int(ceil(left))
		draw_string(font, Vector2(560.0, 102.0), txt, HORIZONTAL_ALIGNMENT_RIGHT, 54.0, 15, col)
		draw_rect(Rect2(346.0, 112.0, 268.0, 8.0), Color(1.0, 1.0, 1.0, 0.15))
		draw_rect(Rect2(346.0, 112.0, 268.0 * frac, 8.0), col)

	if ph != TripScript.PH_NONE:
		var gt: Transform3D = rickshaw.global_transform
		var target: Vector3 = trips.target_position()
		var local: Vector3 = gt.affine_inverse() * target
		var ang := atan2(local.x, -local.z)
		var center := Vector2(480.0, 178.0)
		var arrow_col := Color(1.0, 0.85, 0.15)
		if ph == TripScript.PH_TRIP:
			arrow_col = Color(0.3, 0.95, 0.45)
		draw_circle(center, 34.0, Color(0.07, 0.08, 0.11, 0.6))
		var pts := PackedVector2Array([
			center + Vector2(0.0, -26.0).rotated(ang),
			center + Vector2(-17.0, 17.0).rotated(ang),
			center + Vector2(17.0, 17.0).rotated(ang),
		])
		draw_colored_polygon(pts, arrow_col)

	if _toast_t > 0.0:
		var a := clampf(_toast_t, 0.0, 1.0)
		draw_string(font, Vector2(181.0, 261.0), _toast, HORIZONTAL_ALIGNMENT_CENTER, 600.0, 22, Color(0.0, 0.0, 0.0, 0.7 * a))
		draw_string(font, Vector2(180.0, 260.0), _toast, HORIZONTAL_ALIGNMENT_CENTER, 600.0, 22, Color(1.0, 1.0, 1.0, a))
