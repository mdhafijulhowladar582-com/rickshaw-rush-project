extends RefCounted
## Central look and feel for all UI. Change colours here and every screen follows.

const ACCENT := Color(1.0, 0.78, 0.20)
const PANEL := Color(0.07, 0.08, 0.11, 0.78)


static func make() -> Theme:
	var theme := Theme.new()
	theme.set_stylebox("normal", "Button", _box(PANEL, ACCENT, 2))
	theme.set_stylebox("hover", "Button", _box(Color(0.14, 0.15, 0.20, 0.85), ACCENT, 2))
	theme.set_stylebox("pressed", "Button", _box(Color(1.0, 0.78, 0.20, 0.92), Color.WHITE, 2))
	theme.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	theme.set_color("font_color", "Button", Color.WHITE)
	theme.set_color("font_hover_color", "Button", Color.WHITE)
	theme.set_color("font_pressed_color", "Button", Color(0.10, 0.10, 0.10))
	theme.set_font_size("font_size", "Button", 20)
	theme.set_color("font_disabled_color", "Button", Color(1.0, 1.0, 1.0, 0.4))
	theme.set_stylebox("panel", "PanelContainer", _box(Color(0.07, 0.08, 0.11, 0.96), ACCENT, 2))
	theme.set_font_size("font_size", "Label", 20)
	return theme


static func panel_box() -> StyleBoxFlat:
	return _box(PANEL, Color(1.0, 1.0, 1.0, 0.12), 1)


static func _box(bg: Color, border: Color, border_w: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(border_w)
	s.set_corner_radius_all(14)
	s.set_content_margin_all(10.0)
	return s
