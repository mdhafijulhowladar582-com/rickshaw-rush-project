extends Node
## Day and night cycle, rain, slippery roads, rickshaw headlight and city sound.

signal message(text: String)

const DAY_SECONDS := 360.0        # one full 24 h day in real seconds
const START_HOUR := 9.0

# Sky colour by hour of the day.
const SKY_HOURS: Array[float] = [0.0, 5.0, 6.5, 9.0, 16.0, 18.0, 19.5, 21.0, 24.0]
const SKY_COLORS: Array[Color] = [
	Color(0.03, 0.04, 0.09), Color(0.05, 0.06, 0.12), Color(0.85, 0.55, 0.40),
	Color(0.80, 0.74, 0.62), Color(0.80, 0.74, 0.62), Color(0.88, 0.48, 0.28),
	Color(0.18, 0.13, 0.22), Color(0.04, 0.05, 0.10), Color(0.03, 0.04, 0.09),
]

var fog_base := 0.015
var hour := START_HOUR
var rain := 0.0          # 0..1, how hard it rains right now
var night := 0.0         # 0..1, how dark it is

var env: Environment
var sun: DirectionalLight3D
var rickshaw = null
var cam = null

var _rain_target := 0.0
var _timer := 45.0
var _rng := RandomNumberGenerator.new()
var _rain_fx: CPUParticles3D
var _headlight: SpotLight3D
var _ambient: AudioStreamPlayer
var _rain_snd: AudioStreamPlayer


func setup(e: Environment, s: DirectionalLight3D, r, c) -> void:
	env = e
	sun = s
	rickshaw = r
	cam = c
	_rng.randomize()
	_build_rain()
	_build_headlight()
	_ambient = _make_loop("res://assets/audio/ambient_city.wav", -14.0)
	_rain_snd = _make_loop("res://assets/audio/rain_loop.wav", -60.0)
	_update_sky()


func clock_text() -> String:
	return "%02d:%02d" % [int(hour), int(fmod(hour, 1.0) * 60.0)]


func _process(delta: float) -> void:
	if env == null:
		return
	hour = fmod(hour + delta / DAY_SECONDS * 24.0, 24.0)

	_timer -= delta
	if _timer <= 0.0:
		if _rain_target > 0.0:
			_rain_target = 0.0
			_timer = _rng.randf_range(70.0, 140.0)
			message.emit("The rain stopped.")
		else:
			_rain_target = _rng.randf_range(0.6, 1.0)
			_timer = _rng.randf_range(35.0, 70.0)
			message.emit("Rain! The roads are slippery.")
	rain = move_toward(rain, _rain_target, delta * 0.25)

	_update_sky()
	_update_rain()


func _sample_sky(h: float) -> Color:
	for i in SKY_HOURS.size() - 1:
		var a: float = SKY_HOURS[i]
		var b: float = SKY_HOURS[i + 1]
		if h >= a and h <= b:
			return SKY_COLORS[i].lerp(SKY_COLORS[i + 1], (h - a) / (b - a))
	return SKY_COLORS[0]


func _update_sky() -> void:
	var elev := sin((hour - 6.0) / 12.0 * PI)       # above 0 = sun is up
	night = clampf(1.0 - (elev + 0.15) / 0.45, 0.0, 1.0)

	var sky := _sample_sky(hour)
	var grey := Color(0.45, 0.47, 0.50) * (1.0 - night * 0.85)
	sky = sky.lerp(Color(grey.r, grey.g, grey.b, 1.0), rain * 0.45)

	env.background_color = sky
	env.fog_light_color = sky
	env.fog_density = fog_base * (1.0 + 0.8 * rain)
	env.ambient_light_energy = lerpf(0.65, 0.22, night) * (1.0 - 0.25 * rain)
	env.ambient_light_color = Color(0.85, 0.82, 0.78).lerp(Color(0.45, 0.50, 0.80), night)

	sun.light_energy = maxf(elev, 0.0) * 1.15 * (1.0 - 0.6 * rain)
	sun.light_color = Color(1.0, 0.62, 0.40).lerp(Color(1.0, 0.92, 0.78), clampf(elev * 2.0, 0.0, 1.0))
	sun.rotation_degrees = Vector3(-lerpf(8.0, 62.0, clampf(elev, 0.0, 1.0)), -35.0, 0.0)

	if _headlight != null:
		_headlight.visible = night > 0.25
		_headlight.light_energy = 2.5 * night
	if _ambient != null:
		_ambient.volume_db = lerpf(-12.0, -22.0, night)
	if _rain_snd != null:
		if rain < 0.02:
			_rain_snd.volume_db = -60.0
		else:
			_rain_snd.volume_db = lerpf(-30.0, -8.0, rain)


func _update_rain() -> void:
	if cam == null:
		return
	_rain_fx.emitting = rain > 0.05
	var cp: Vector3 = cam.global_position
	_rain_fx.global_position = cp + Vector3(0.0, 9.0, 0.0)
	if rickshaw != null:
		rickshaw.road_grip_mult = lerpf(1.0, 0.62, rain)


func _build_rain() -> void:
	_rain_fx = CPUParticles3D.new()
	_rain_fx.amount = 400
	_rain_fx.lifetime = 0.9
	_rain_fx.local_coords = false
	_rain_fx.emitting = false
	_rain_fx.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	_rain_fx.emission_box_extents = Vector3(16.0, 0.2, 16.0)
	_rain_fx.direction = Vector3(0.0, -1.0, 0.0)
	_rain_fx.spread = 2.0
	_rain_fx.initial_velocity_min = 22.0
	_rain_fx.initial_velocity_max = 26.0
	_rain_fx.gravity = Vector3(0.0, -8.0, 0.0)
	_rain_fx.extra_cull_margin = 200.0

	var drop := BoxMesh.new()
	drop.size = Vector3(0.025, 0.55, 0.025)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = Color(0.80, 0.85, 0.95, 0.45)
	m.disable_fog = true
	drop.material = m
	_rain_fx.mesh = drop
	add_child(_rain_fx)


func _build_headlight() -> void:
	if rickshaw == null:
		return
	_headlight = SpotLight3D.new()
	_headlight.position = Vector3(0.0, 1.1, -1.3)
	_headlight.rotation_degrees = Vector3(-6.0, 0.0, 0.0)
	_headlight.spot_range = 45.0
	_headlight.spot_angle = 40.0
	_headlight.light_energy = 0.0
	_headlight.light_color = Color(1.0, 0.95, 0.80)
	_headlight.shadow_enabled = false
	_headlight.visible = false
	rickshaw.add_child(_headlight)


func _make_loop(path: String, volume: float) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.volume_db = volume
	add_child(p)
	if ResourceLoader.exists(path):
		var stream = load(path)
		if stream is AudioStreamWAV:
			stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
			stream.loop_begin = 0
			stream.loop_end = int(stream.data.size() / 2)
		p.stream = stream
		p.play()
	return p
