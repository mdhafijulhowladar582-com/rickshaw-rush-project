extends Node3D
## Real character models for the passenger waiting at the yellow marker
## (one look for each kind of passenger).

const DIR := "res://assets/models/people/blocky/"
const LOOKS: Array[String] = ["character-a", "character-b", "character-e", "character-h", "character-k", "character-l"]
const SCALE := 0.62

var _lib = null
var _figures: Array = []
var _loaded := 0


func setup(lib) -> bool:
	_lib = lib
	for i in LOOKS.size():
		var holder := Node3D.new()
		add_child(holder)
		var packed: PackedScene = _lib.scene(DIR + LOOKS[i] + ".glb")
		if packed != null:
			var model: Node3D = packed.instantiate()
			model.rotation.y = PI
			model.scale = Vector3.ONE * SCALE
			holder.add_child(model)
			_lib.play_loop(_lib.find_player(model), "idle")
			_loaded += 1
		holder.visible = false
		_figures.append(holder)
	return _loaded >= 3


func show_type(i: int) -> void:
	for k in _figures.size():
		var f: Node3D = _figures[k]
		f.visible = (k == i)
