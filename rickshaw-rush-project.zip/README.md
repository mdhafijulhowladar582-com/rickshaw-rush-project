# Rickshaw Rush

3D Dhaka rickshaw driving and career game, built with Godot 4.4 (GL Compatibility renderer).

## Status: phase 2

- Android build pipeline (GitHub Actions)
- Performance test city (adjustable density and graphics quality, FPS / draw calls / triangles on screen)
- Drivable rickshaw: arcade handling, stamina, skid, chase camera, touch controls
- Passenger jobs: pick up at the yellow marker, drop off at the green marker, fare + tip (or late penalty)
- Cash, Garage with 4 upgrades (tires, chain, legs, seat) and hood repaint, progress saved on the phone
- Solid buildings and city edge walls

## Controls

Touch (landscape): left side = floating steering stick (pull down to brake), PEDAL = hold to pedal, BELL = tap.
Slow down inside the marker circle to pick up or drop off. GARAGE button (top right) opens the upgrade shop.

Desktop: A/D or arrows steer, W/Up/Space pedal, S/Down brake, B bell, R reset.

## Get the APK from GitHub

1. Put `.github/workflows/build-apk.yml` in the repo.
2. Upload either the project files as they are, or only `rickshaw-rush-project.zip`, to the repo root.
3. Open the Actions tab, run "Build Android APK" (it also runs on every push).
4. Download the `RickshawRush-debug-apk` artifact from the finished run, unzip it, install the APK.

`debug.keystore` is included so every new build installs over the previous one.

## Layout

    scenes/main.tscn            single entry scene
    scripts/main.gd             world setup, input, perf test buttons, garage hookup
    scripts/game/               save data + upgrades, passenger/trip manager
    scripts/player/             rickshaw model + controller, chase camera
    scripts/world/city.gd       procedural city (MultiMesh based) + collision
    scripts/ui/                 theme, touch controls, HUD, trip HUD, garage panel
    assets/audio/bell.wav       generated bell sound
