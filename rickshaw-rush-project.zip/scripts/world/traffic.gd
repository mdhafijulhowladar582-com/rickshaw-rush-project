extends Node3D
## Moving traffic on the road grid: cars, buses and other rickshaws drive on the left,
## turn at crossings, slow down for whatever is in front and honk at you.

signal fined(amount: int, reason: String)
signal notice(text: String)

const CityScript = preload("res://scripts/world/city.gd")

const COUNT := 40            # 26 always on the road, the rest only in rush hour
const BASE_COUNT := 26
const LANE := 2.2
const LOOK_AHEAD := 11.0

const KIND_CAR := 0
const KIND_BUS := 1
const KIND_RICK := 2
const KIND_POLICE := 3

const COLORS: Array[Color] = [
	Color(0.85, 0.85, 0.80), Color(0.75, 0.15, 0.15), Color(0.20, 0.35, 0.65),
	Color(0.95, 0.80, 0.20), Color(0.25, 0.25, 0.28), Color(0.20, 0.55, 0.40),
]

class Vehicle extends RefCounted:
	var node: AnimatableBody3D
	var ix := 0
	var iz := 0
	var dir := Vector2i(1, 0)
	var along := 0.0
	var speed := 0.0
	var base_speed := 6.0
	var lat := Vector3.ZERO
	var kind := 0
	var active := true
	var siren_a: StandardMaterial3D
	var siren_b: StandardMaterial3D

var rickshaw = null
var lights = null          # traffic_signals.gd, optional
var weather = null         # weather.gd, optional

var _vehicles: Array = []
var _rng := RandomNumberGenerator.new()
var _glass: StandardMaterial3D
var _horn_player: AudioStreamPlayer
var _horn_car = null
var _horn_bus = null
var _horn_cd := 0.0
var _fine_cd := 0.0
var _t := 0.0
var _rush := false


func setup(r) -> void:
	rickshaw = r
	_rng.randomize()
	_glass = StandardMaterial3D.new()
	_glass.albedo_color = Color(0.12, 0.16, 0.20)
	_glass.roughness = 0.4
	_horn_car = _load_sound("res://assets/audio/horn_car.wav")
	_horn_bus = _load_sound("res://assets/audio/horn_bus.wav")
	_horn_player = AudioStreamPlayer.new()
	add_child(_horn_player)
	for i in COUNT:
		_spawn(i)


func _load_sound(path: String):
	if ResourceLoader.exists(path):
		return load(path)
	return null


func _grid_pos(ix: int, iz: int) -> Vector3:
	var half := float(CityScript.BLOCKS) * 0.5
	return Vector3((float(ix) - half) * CityScript.PITCH, 0.04, (float(iz) - half) * CityScript.PITCH)


func _spawn(i: int) -> void:
	var v := Vehicle.new()
	var kind := KIND_CAR
	if i % 5 == 0:
		kind = KIND_BUS
	elif i % 5 == 3:
		kind = KIND_RICK
	if i == 7 or i == 17:
		kind = KIND_POLICE
	v.kind = kind

	var half := CityScript.BLOCKS / 2
	for attempt in 20:
		v.ix = _rng.randi_range(0, CityScript.BLOCKS)
		v.iz = _rng.randi_range(0, CityScript.BLOCKS)
		if absi(v.ix - half) + absi(v.iz - half) >= 2:
			break
	var dirs: Array[Vector2i] = [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
	v.dir = dirs[_rng.randi() % 4]
	var nx := v.ix + v.dir.x
	var nz := v.iz + v.dir.y
	if nx < 0 or nx > CityScript.BLOCKS or nz < 0 or nz > CityScript.BLOCKS:
		v.dir = Vector2i(-v.dir.x, -v.dir.y)
	v.along = _rng.randf_range(0.0, CityScript.PITCH * 0.8)

	if kind == KIND_BUS:
		v.base_speed = _rng.randf_range(4.0, 6.0)
	elif kind == KIND_RICK:
		v.base_speed = _rng.randf_range(3.0, 4.5)
	else:
		v.base_speed = _rng.randf_range(5.0, 8.0)
	v.speed = v.base_speed

	v.node = _make_node(kind, COLORS[_rng.randi() % COLORS.size()], v)
	add_child(v.node)
	var dvec := Vector3(float(v.dir.x), 0.0, float(v.dir.y))
	var left := Vector3(dvec.z, 0.0, -dvec.x)
	v.lat = left * LANE
	v.node.global_position = _grid_pos(v.ix, v.iz) + dvec * v.along + v.lat
	v.node.rotation.y = atan2(-dvec.x, -dvec.z)
	v.node.reset_physics_interpolation()
	_vehicles.append(v)
	if i >= BASE_COUNT:
		v.active = false
		v.node.visible = false
		v.node.collision_layer = 0


func _physics_process(delta: float) -> void:
	if rickshaw == null:
		return
	var rp: Vector3 = rickshaw.global_position
	_horn_cd = maxf(_horn_cd - delta, 0.0)
	_fine_cd = maxf(_fine_cd - delta, 0.0)
	_t += delta

	# Rush hours: more and slower traffic.
	var rush := false
	if weather != null:
		var h: float = weather.hour
		rush = (h >= 8.0 and h < 10.0) or (h >= 17.0 and h < 19.5)
	if rush != _rush:
		_rush = rush
		if _rush:
			notice.emit("Rush hour! The roads are packed.")
		else:
			notice.emit("The traffic is clearing up.")

	var flash := int(_t * 4.0) % 2 == 0
	for i in _vehicles.size():
		var v: Vehicle = _vehicles[i]
		var should := i < BASE_COUNT or _rush
		if should != v.active:
			v.active = should
			v.node.visible = should
			if should:
				v.node.collision_layer = 1
				v.node.reset_physics_interpolation()
			else:
				v.node.collision_layer = 0
		if not v.active:
			continue
		_step(v, delta, rp)
		if v.siren_a != null:
			if flash:
				v.siren_a.albedo_color = Color(1.0, 0.1, 0.1)
				v.siren_b.albedo_color = Color(0.1, 0.15, 0.3)
			else:
				v.siren_a.albedo_color = Color(0.3, 0.0, 0.0)
				v.siren_b.albedo_color = Color(0.3, 0.5, 1.0)


func _step(v: Vehicle, delta: float, rp: Vector3) -> void:
	var dvec := Vector3(float(v.dir.x), 0.0, float(v.dir.y))
	var side_axis := Vector3(-dvec.z, 0.0, dvec.x)
	var here: Vector3 = v.node.global_position

	# Brake for the player or for a slower vehicle going the same way.
	var target_speed := v.base_speed
	if _rush:
		target_speed *= 0.65
	var to_p := rp - here
	to_p.y = 0.0
	var ahead := to_p.dot(dvec)

	# Police fine you for speeding right past them.
	if v.kind == KIND_POLICE and _fine_cd <= 0.0:
		var player_speed: float = absf(rickshaw.forward_speed)
		if to_p.length() < 22.0 and player_speed > 9.5:
			_fine_cd = 25.0
			fined.emit(30, "Police: slow down! Fine Tk 30")

	# Stop at a red (or late yellow) light on the next crossing.
	if lights != null:
		var nx := v.ix + v.dir.x
		var nz := v.iz + v.dir.y
		if lights.has_signal(nx, nz):
			var remaining := CityScript.PITCH - v.along
			if remaining > 4.6 and remaining < 15.0:
				var light_state: int = lights.light_for(v.dir.x != 0)
				if light_state == 2 or (light_state == 1 and remaining > 9.0):
					target_speed = 0.0
	if ahead > 0.0 and ahead < LOOK_AHEAD and absf(to_p.dot(side_axis)) < 2.6:
		target_speed = 0.0
		if ahead < 9.0 and _horn_cd <= 0.0:
			_honk(v, ahead)
	for o in _vehicles:
		if o == v or o.dir != v.dir:
			continue
		var to_o: Vector3 = o.node.global_position - here
		var o_ahead := to_o.dot(dvec)
		if o_ahead > 0.0 and o_ahead < 9.0 and absf(to_o.dot(side_axis)) < 1.8:
			target_speed = minf(target_speed, 0.0)

	v.speed = move_toward(v.speed, target_speed, 9.0 * delta)
	v.along += v.speed * delta

	if v.along >= CityScript.PITCH:
		v.along -= CityScript.PITCH
		v.ix += v.dir.x
		v.iz += v.dir.y
		v.dir = _choose_dir(v.ix, v.iz, v.dir)
		dvec = Vector3(float(v.dir.x), 0.0, float(v.dir.y))

	var left := Vector3(dvec.z, 0.0, -dvec.x)
	v.lat = v.lat.lerp(left * LANE, 1.0 - exp(-3.0 * delta))
	var pos := _grid_pos(v.ix, v.iz) + dvec * v.along + v.lat
	pos.y = 0.04
	v.node.global_position = pos
	var yaw := atan2(-dvec.x, -dvec.z)
	v.node.rotation.y = lerp_angle(v.node.rotation.y, yaw, 1.0 - exp(-6.0 * delta))


func _choose_dir(ix: int, iz: int, d: Vector2i) -> Vector2i:
	var cands: Array[Vector2i] = [d, Vector2i(-d.y, d.x), Vector2i(d.y, -d.x)]
	var weights: Array[float] = [0.6, 0.2, 0.2]
	var options: Array[Vector2i] = []
	var opt_w: Array[float] = []
	var total := 0.0
	for k in 3:
		var c: Vector2i = cands[k]
		var nx := ix + c.x
		var nz := iz + c.y
		if nx < 0 or nx > CityScript.BLOCKS or nz < 0 or nz > CityScript.BLOCKS:
			continue
		options.append(c)
		opt_w.append(weights[k])
		total += weights[k]
	if options.is_empty():
		return Vector2i(-d.x, -d.y)
	var r := _rng.randf() * total
	for k in options.size():
		r -= opt_w[k]
		if r <= 0.0:
			return options[k]
	return options[options.size() - 1]


func _honk(v: Vehicle, dist: float) -> void:
	_horn_cd = _rng.randf_range(3.0, 5.0)
	var snd = _horn_car
	if v.kind == KIND_BUS:
		snd = _horn_bus
	if snd == null:
		return
	_horn_player.stream = snd
	_horn_player.volume_db = -4.0 - dist
	_horn_player.play()


func _siren_mat() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(0.3, 0.0, 0.0)
	return m


func _make_node(kind: int, color: Color, v: Vehicle) -> AnimatableBody3D:
	var body := AnimatableBody3D.new()
	body.sync_to_physics = true
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.9

	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	if kind == KIND_POLICE:
		mat.albedo_color = Color(0.92, 0.92, 0.95)
		_add_box(body, Vector3(1.9, 0.75, 4.2), Vector3(0.0, 0.65, 0.0), mat)
		_add_box(body, Vector3(1.6, 0.6, 2.2), Vector3(0.0, 1.3, 0.2), _glass)
		var stripe := StandardMaterial3D.new()
		stripe.albedo_color = Color(0.1, 0.25, 0.7)
		_add_box(body, Vector3(1.93, 0.18, 4.22), Vector3(0.0, 0.7, 0.0), stripe)
		v.siren_a = _siren_mat()
		v.siren_b = _siren_mat()
		_add_box(body, Vector3(0.5, 0.18, 0.35), Vector3(-0.4, 1.68, 0.2), v.siren_a)
		_add_box(body, Vector3(0.5, 0.18, 0.35), Vector3(0.4, 1.68, 0.2), v.siren_b)
		box.size = Vector3(1.9, 1.5, 4.2)
		shape.position = Vector3(0.0, 0.9, 0.0)
	elif kind == KIND_BUS:
		_add_box(body, Vector3(2.6, 2.9, 9.0), Vector3(0.0, 1.75, 0.0), mat)
		_add_box(body, Vector3(2.64, 0.8, 7.6), Vector3(0.0, 2.25, 0.0), _glass)
		box.size = Vector3(2.6, 2.9, 9.0)
		shape.position = Vector3(0.0, 1.7, 0.0)
	elif kind == KIND_RICK:
		_add_box(body, Vector3(1.2, 0.9, 2.2), Vector3(0.0, 0.8, 0.0), mat)
		_add_box(body, Vector3(1.35, 0.08, 1.7), Vector3(0.0, 1.55, 0.2), _glass)
		box.size = Vector3(1.3, 1.6, 2.4)
		shape.position = Vector3(0.0, 0.95, 0.0)
	else:
		_add_box(body, Vector3(1.9, 0.75, 4.2), Vector3(0.0, 0.65, 0.0), mat)
		_add_box(body, Vector3(1.6, 0.6, 2.2), Vector3(0.0, 1.3, 0.2), _glass)
		box.size = Vector3(1.9, 1.5, 4.2)
		shape.position = Vector3(0.0, 0.9, 0.0)
	shape.shape = box
	body.add_child(shape)
	return body


func _add_box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material) -> void:
	var mi := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.position = pos
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
