extends Control
## Heads-up display: speed, stamina, and a small performance panel for the
## device test (FPS, draw calls, triangles).

const UiTheme = preload("res://scripts/ui/ui_theme.gd")

var rickshaw = null
var info_text := ""
var show_stats := false

var _card: StyleBoxFlat


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_card = UiTheme.panel_box()


func _process(_delta: float) -> void:
	queue_redraw()


func _draw() -> void:
	if rickshaw == null:
		return
	var font := ThemeDB.fallback_font

	# Speed + stamina
	draw_style_box(_card, Rect2(20.0, 20.0, 230.0, 112.0))
	var kmh := str(int(round(absf(rickshaw.forward_speed) * 3.6)))
	draw_string(font, Vector2(38.0, 80.0), kmh, HORIZONTAL_ALIGNMENT_LEFT, -1, 52, Color.WHITE)
	var w := font.get_string_size(kmh, HORIZONTAL_ALIGNMENT_LEFT, -1, 52).x
	draw_string(font, Vector2(46.0 + w, 80.0), "km/h", HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(1.0, 1.0, 1.0, 0.7))
	draw_string(font, Vector2(38.0, 104.0), "STAMINA", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(1.0, 1.0, 1.0, 0.7))
	draw_rect(Rect2(38.0, 110.0, 192.0, 11.0), Color(1.0, 1.0, 1.0, 0.15))
	var st: float = rickshaw.stamina
	var bar_col := Color(0.9, 0.25, 0.2).lerp(Color(0.35, 0.85, 0.35), clampf(st * 1.6, 0.0, 1.0))
	draw_rect(Rect2(38.0, 110.0, 192.0 * st, 11.0), bar_col)

	if not show_stats:
		return

	# Performance panel
	var fps := Engine.get_frames_per_second()
	var fps_col := Color(1.0, 0.4, 0.35)
	if fps >= 50.0:
		fps_col = Color(0.4, 0.95, 0.45)
	elif fps >= 30.0:
		fps_col = Color(1.0, 0.85, 0.3)
	var calls := RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME)
	var prims := RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME)
	draw_style_box(_card, Rect2(20.0, 142.0, 230.0, 106.0))
	draw_string(font, Vector2(38.0, 174.0), "FPS  %d" % int(fps), HORIZONTAL_ALIGNMENT_LEFT, -1, 26, fps_col)
	draw_string(font, Vector2(38.0, 198.0), "Draw calls  %d" % int(calls), HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(1.0, 1.0, 1.0, 0.85))
	draw_string(font, Vector2(38.0, 218.0), "Triangles  %.1fk" % (float(prims) / 1000.0), HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(1.0, 1.0, 1.0, 0.85))
	draw_string(font, Vector2(38.0, 238.0), info_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(1.0, 1.0, 1.0, 0.85))
