extends RefCounted
## Loads the baked 3D models in assets/models. It fails soft: a missing or broken model
## gives null and the caller keeps its simple box version.

var _meshes: Dictionary = {}
var _scenes: Dictionary = {}


func scene(path: String) -> PackedScene:
	if _scenes.has(path):
		return _scenes[path]
	var result: PackedScene = null
	if ResourceLoader.exists(path):
		var s = load(path)
		if s is PackedScene:
			result = s
	_scenes[path] = result
	return result


func mesh(path: String) -> Mesh:
	if _meshes.has(path):
		return _meshes[path]
	var result: Mesh = null
	var packed := scene(path)
	if packed != null:
		var inst: Node = packed.instantiate()
		var mi := _find_mesh_instance(inst)
		if mi != null:
			result = mi.mesh
		inst.free()
	_meshes[path] = result
	return result


func _find_mesh_instance(node: Node) -> MeshInstance3D:
	if node is MeshInstance3D and (node as MeshInstance3D).mesh != null:
		return node as MeshInstance3D
	for c in node.get_children():
		var r := _find_mesh_instance(c)
		if r != null:
			return r
	return null


## A new MeshInstance3D showing the model, or null when it is not available.
func make_mesh_instance(path: String, range_end: float = 0.0) -> MeshInstance3D:
	var m := mesh(path)
	if m == null:
		return null
	var mi := MeshInstance3D.new()
	mi.mesh = m
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	if range_end > 0.0:
		mi.visibility_range_end = range_end
	return mi


## Many copies of one model in a single draw call; hidden when further than range_end.
func add_multimesh(parent: Node, m: Mesh, xforms: Array, range_end: float) -> void:
	if m == null or xforms.is_empty():
		return
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = m
	mm.instance_count = xforms.size()
	for i in xforms.size():
		mm.set_instance_transform(i, xforms[i])
	var inst := MultiMeshInstance3D.new()
	inst.multimesh = mm
	inst.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	inst.visibility_range_end = range_end
	parent.add_child(inst)


## First AnimationPlayer below a node (imported characters carry their animations).
func find_player(node: Node) -> AnimationPlayer:
	if node is AnimationPlayer:
		return node as AnimationPlayer
	for c in node.get_children():
		var r := find_player(c)
		if r != null:
			return r
	return null


## Play an animation in a loop; returns false if the model does not have it.
func play_loop(player: AnimationPlayer, anim_name: String, speed: float = 1.0) -> bool:
	if player == null or not player.has_animation(anim_name):
		return false
	var a := player.get_animation(anim_name)
	a.loop_mode = Animation.LOOP_LINEAR
	player.speed_scale = speed
	player.play(anim_name)
	return true
