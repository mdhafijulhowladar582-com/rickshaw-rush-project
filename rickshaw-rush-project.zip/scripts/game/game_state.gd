extends RefCounted
## Everything that is saved between play sessions: cash, upgrades, paint colour.

const SAVE_PATH := "user://rickshaw_save.cfg"
const MAX_LEVEL := 3
const PAINT_COST := 40

const UP_NAMES: Array[String] = ["Better tires", "Smooth chain", "Strong legs", "Comfy seat"]
const UP_DESCS: Array[String] = [
	"More grip and a little more top speed",
	"Faster acceleration",
	"Stamina lasts longer",
	"Passengers tip more",
]
const UP_COSTS: Array = [[120, 300, 650], [100, 260, 560], [140, 320, 620], [150, 350, 700]]

const PAINT_COLORS: Array[Color] = [
	Color(0.78, 0.10, 0.12), Color(0.15, 0.35, 0.80), Color(0.10, 0.55, 0.30),
	Color(0.55, 0.25, 0.70), Color(0.95, 0.45, 0.10), Color(0.90, 0.30, 0.55),
]

var money := 0
var trips := 0
var paint := 0
var levels: Array[int] = [0, 0, 0, 0]


func upgrade_cost(i: int) -> int:
	var lv: int = levels[i]
	if lv >= MAX_LEVEL:
		return -1
	var costs: Array = UP_COSTS[i]
	return int(costs[lv])


func try_buy(i: int) -> bool:
	var cost: int = upgrade_cost(i)
	if cost < 0 or money < cost:
		return false
	money -= cost
	levels[i] += 1
	save_game()
	return true


func try_repaint() -> bool:
	if money < PAINT_COST:
		return false
	money -= PAINT_COST
	paint = (paint + 1) % PAINT_COLORS.size()
	save_game()
	return true


func paint_color() -> Color:
	return PAINT_COLORS[paint]


func save_game() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("game", "money", money)
	cfg.set_value("game", "trips", trips)
	cfg.set_value("game", "paint", paint)
	cfg.set_value("game", "levels", levels)
	cfg.save(SAVE_PATH)


func load_game() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	money = maxi(int(cfg.get_value("game", "money", 0)), 0)
	trips = maxi(int(cfg.get_value("game", "trips", 0)), 0)
	paint = clampi(int(cfg.get_value("game", "paint", 0)), 0, PAINT_COLORS.size() - 1)
	var saved: Array = cfg.get_value("game", "levels", [0, 0, 0, 0])
	for i in levels.size():
		if i < saved.size():
			levels[i] = clampi(int(saved[i]), 0, MAX_LEVEL)
