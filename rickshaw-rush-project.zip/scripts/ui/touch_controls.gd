extends Control
## On-screen controls (landscape): floating steering stick on the left,
## PEDAL (hold) and BELL (tap) on the right. Multi-touch safe.
## Pull the stick down to brake.

signal bell_pressed

const JOY_RADIUS := 90.0
const PEDAL_RADIUS := 82.0
const BELL_RADIUS := 50.0

var steer := 0.0
var brake := 0.0
var pedal_down := false

var _joy_id := -1
var _pedal_id := -1
var _bell_id := -1
var _joy_origin := Vector2.ZERO
var _joy_pos := Vector2.ZERO
var _bell_flash := 0.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


## Forget every finger (used when a menu opens and swallows the release events).
func release_all() -> void:
	_joy_id = -1
	_pedal_id = -1
	_bell_id = -1
	steer = 0.0
	brake = 0.0
	pedal_down = false


func _pedal_center() -> Vector2:
	return Vector2(size.x - 120.0, size.y - 120.0)


func _bell_center() -> Vector2:
	return Vector2(size.x - 275.0, size.y - 92.0)


func _joy_zone() -> Rect2:
	return Rect2(0.0, size.y * 0.30, size.x * 0.45, size.y * 0.70)


func _joy_rest() -> Vector2:
	return Vector2(150.0, size.y - 130.0)


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var p: Vector2 = event.position
		if event.pressed:
			if _pedal_id == -1 and p.distance_to(_pedal_center()) <= PEDAL_RADIUS * 1.15:
				_pedal_id = event.index
				pedal_down = true
			elif _bell_id == -1 and p.distance_to(_bell_center()) <= BELL_RADIUS * 1.25:
				_bell_id = event.index
				_bell_flash = 1.0
				bell_pressed.emit()
			elif _joy_id == -1 and _joy_zone().has_point(p):
				_joy_id = event.index
				_joy_origin = p
				_joy_pos = p
				_update_stick()
		else:
			if event.index == _pedal_id:
				_pedal_id = -1
				pedal_down = false
			elif event.index == _bell_id:
				_bell_id = -1
			elif event.index == _joy_id:
				_joy_id = -1
				steer = 0.0
				brake = 0.0
	elif event is InputEventScreenDrag:
		if event.index == _joy_id:
			_joy_pos = event.position
			_update_stick()


func _update_stick() -> void:
	var v := ((_joy_pos - _joy_origin) / JOY_RADIUS).limit_length(1.0)
	steer = signf(v.x) * clampf((absf(v.x) - 0.10) / 0.90, 0.0, 1.0)
	brake = clampf((v.y - 0.45) / 0.55, 0.0, 1.0)


func _process(delta: float) -> void:
	_bell_flash = maxf(_bell_flash - delta * 4.0, 0.0)
	queue_redraw()


func _draw() -> void:
	var font := ThemeDB.fallback_font
	var active := _joy_id != -1
	var base := _joy_origin if active else _joy_rest()
	var knob := (_joy_pos - base).limit_length(JOY_RADIUS) if active else Vector2.ZERO
	draw_circle(base, JOY_RADIUS, Color(1.0, 1.0, 1.0, 0.10))
	draw_arc(base, JOY_RADIUS, 0.0, TAU, 48, Color(1.0, 1.0, 1.0, 0.45), 3.0, true)
	draw_circle(base + knob, 36.0, Color(1.0, 0.80, 0.22, 0.85 if active else 0.55))
	if not active:
		draw_string(font, base + Vector2(-60.0, -JOY_RADIUS - 12.0), "STEER  (pull down = brake)", HORIZONTAL_ALIGNMENT_CENTER, 120.0, 14, Color(1.0, 1.0, 1.0, 0.6))

	var pc := _pedal_center()
	var down := _pedal_id != -1
	draw_circle(pc, PEDAL_RADIUS, Color(0.95, 0.35, 0.18, 0.90 if down else 0.55))
	draw_arc(pc, PEDAL_RADIUS, 0.0, TAU, 48, Color(1.0, 1.0, 1.0, 0.85), 3.0, true)
	draw_string(font, pc + Vector2(-60.0, 8.0), "PEDAL", HORIZONTAL_ALIGNMENT_CENTER, 120.0, 24, Color.WHITE)

	var bc := _bell_center()
	draw_circle(bc, BELL_RADIUS, Color(0.98, 0.78, 0.14, 0.55 + 0.4 * _bell_flash))
	draw_arc(bc, BELL_RADIUS, 0.0, TAU, 40, Color(1.0, 1.0, 1.0, 0.85), 3.0, true)
	draw_string(font, bc + Vector2(-50.0, 7.0), "BELL", HORIZONTAL_ALIGNMENT_CENTER, 100.0, 20, Color(0.1, 0.1, 0.1))
