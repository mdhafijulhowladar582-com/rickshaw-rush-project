extends Node3D
## Street food floating above the road. Drive through it to refill your stamina.

signal collected(text: String)

const CityScript = preload("res://scripts/world/city.gd")

const COUNT := 6
const DIR := "res://assets/models/food/"
const FOODS: Array[String] = ["apple", "banana", "burger", "cup-tea", "donut", "ice-cream-cne", "cupcake", "croissant", "cookie", "orange"]
const NAMES: Array[String] = ["an apple", "a banana", "a burger", "hot tea", "a donut", "ice cream", "a cupcake", "a croissant", "a cookie", "an orange"]
const REFILL := 0.5
const PICK_RADIUS := 2.8
const FAR := 190.0

var rickshaw = null

var _lib = null
var _rng := RandomNumberGenerator.new()
var _items: Array = []       # each entry: [holder Node3D, food index int]
var _spin := 0.0


func setup(r) -> void:
	rickshaw = r
	_rng.randomize()
	var s = load("res://scripts/world/model_lib.gd")
	if s == null or not s.can_instantiate():
		return
	_lib = s.new()
	for i in COUNT:
		var holder := Node3D.new()
		add_child(holder)
		_items.append([holder, -1])
		_respawn(i, Vector3.ZERO)


func _grid_pos(ix: int, iz: int) -> Vector3:
	var half := float(CityScript.BLOCKS) * 0.5
	return Vector3((float(ix) - half) * CityScript.PITCH, 0.0, (float(iz) - half) * CityScript.PITCH)


func _grid_index(v: float) -> int:
	return clampi(roundi(v / CityScript.PITCH + float(CityScript.BLOCKS) * 0.5), 0, CityScript.BLOCKS)


func _respawn(i: int, around: Vector3) -> void:
	var entry: Array = _items[i]
	var holder: Node3D = entry[0]
	for c in holder.get_children():
		c.queue_free()
	var food := _rng.randi() % FOODS.size()
	entry[1] = food
	var mi: MeshInstance3D = _lib.make_mesh_instance(DIR + FOODS[food] + ".glb", 230.0)
	if mi != null:
		mi.position = Vector3(0.0, 1.3, 0.0)
		holder.add_child(mi)
	var gx := _grid_index(around.x) + _rng.randi_range(-5, 5)
	var gz := _grid_index(around.z) + _rng.randi_range(-5, 5)
	gx = clampi(gx, 0, CityScript.BLOCKS)
	gz = clampi(gz, 0, CityScript.BLOCKS)
	var p := _grid_pos(gx, gz)
	holder.position = p + Vector3(_rng.randf_range(-1.5, 1.5), 0.0, _rng.randf_range(-1.5, 1.5))
	holder.reset_physics_interpolation()


func _physics_process(delta: float) -> void:
	if rickshaw == null or _lib == null:
		return
	_spin += delta
	var rp: Vector3 = rickshaw.global_position
	for i in _items.size():
		var entry: Array = _items[i]
		var holder: Node3D = entry[0]
		holder.rotation.y = _spin * 1.6
		var d := Vector2(holder.position.x - rp.x, holder.position.z - rp.z).length()
		if d > FAR:
			_respawn(i, rp)
		elif d < PICK_RADIUS:
			var food: int = entry[1]
			rickshaw.stamina = minf(float(rickshaw.stamina) + REFILL, 1.0)
			collected.emit("Yum! You grabbed %s|Stamina refilled" % NAMES[food])
			_respawn(i, rp)
